"""Public interface to the native implementation."""
# Native core SHA256: 66e3b09ddeabff8b34ca9ea87cde133a3fe2f2d3c19851532a30bb6dad944e7a
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_format_enrichment_output_083bb798eadb2d63' if __name__ == "__main__" else '_ybcore_format_enrichment_output_083bb798eadb2d63'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_083bb798eadb2d63', '__yb_builtins_083bb798eadb2d63']})
