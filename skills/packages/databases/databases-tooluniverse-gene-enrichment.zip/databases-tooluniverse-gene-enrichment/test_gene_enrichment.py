"""Public interface to the native implementation."""
# Native core SHA256: b6d2f8ae984dae71061a721a336c9df095481e94fcf13f5ebf3fd1a222e05238
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_test_gene_enrichment_d21a2ad77773c90f' if __name__ == "__main__" else '_ybcore_test_gene_enrichment_d21a2ad77773c90f'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_d21a2ad77773c90f', '__yb_builtins_d21a2ad77773c90f']})
