"""Public interface to the native implementation."""
# Native core SHA256: 2587060046a60d24dd7c4be8802940c30f7576421fcf52fc1699777692303e77
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_proximity_analysis_338eba537c2672cb'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_338eba537c2672cb', '__yb_builtins_338eba537c2672cb']})
