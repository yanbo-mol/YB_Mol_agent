"""Public interface to the native implementation."""
# Native core SHA256: dbb8c6c3f907a750ceb5a7e0253afb2ef086b4e31d39c2712ff5237ba6287d55
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_primer_design_70fd14deaa77ce25'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_70fd14deaa77ce25', '__yb_builtins_70fd14deaa77ce25']})
