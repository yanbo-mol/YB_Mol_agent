"""Public interface to the native implementation."""
# Native core SHA256: 7b1e058232c5f6fa5d6ce1af8c3dfc257590a9869d4a8cd860fac8f64dff7e4f
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_palindrome_check_4346e6d32aaf1be2'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_4346e6d32aaf1be2', '__yb_builtins_4346e6d32aaf1be2']})
