"""Public interface to the native implementation."""
# Native core SHA256: 0a23214f37baa185aa06091b364694c7fde8359f6234b70f9f6e9d6e0432a2d5
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_spatialdata_workflow_f85254f27242f936'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_f85254f27242f936', '__yb_builtins_f85254f27242f936']})
