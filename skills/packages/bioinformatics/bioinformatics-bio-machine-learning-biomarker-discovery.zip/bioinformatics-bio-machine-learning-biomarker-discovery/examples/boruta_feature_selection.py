"""Public interface to the native implementation."""
# Native core SHA256: 21a89875e2462ccb5ec6606a8c9e7ec1ac60754ec4f54b7e5f8bb575e40ce0cc
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_boruta_feature_selection_9ff2344c7a5cf761'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_9ff2344c7a5cf761', '__yb_builtins_9ff2344c7a5cf761']})
