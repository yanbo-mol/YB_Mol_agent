"""Public interface to the native implementation."""
# Native core SHA256: 6a14a73e975f8d253884fa11b515304ef8b605b0c23356009c7392e381b33eb1
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_prime_editing_design_94aa1b0ba09e7216' if __name__ == "__main__" else '_ybcore_prime_editing_design_94aa1b0ba09e7216'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_94aa1b0ba09e7216', '__yb_builtins_94aa1b0ba09e7216']})
