"""Public interface to the native implementation."""
# Native core SHA256: 033baa9f63a0b0437906e221c7e0c9cfc3db216bce216028d1d3a305d5fede8a
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_qc_analysis_a1320dd8ce647d13'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_a1320dd8ce647d13', '__yb_builtins_a1320dd8ce647d13']})
