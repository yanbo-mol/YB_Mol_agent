"""Public interface to the native implementation."""
# Native core SHA256: 49d51180c0dc24dcb8b9ad33dc380a64fe4febae2f6737f94b4c3fb1f8aadcd9
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_batch_fasta_663503b136b72174'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_663503b136b72174', '__yb_builtins_663503b136b72174']})
