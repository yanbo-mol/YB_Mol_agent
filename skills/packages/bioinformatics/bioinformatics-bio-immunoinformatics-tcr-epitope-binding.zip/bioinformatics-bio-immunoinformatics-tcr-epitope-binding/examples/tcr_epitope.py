"""Public interface to the native implementation."""
# Native core SHA256: 7a1f0144eec54017facdcf3fbcfcfd4d7873db2d5ba75c8177a1e323c6573935
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_tcr_epitope_35c38a8b70d4e403' if __name__ == "__main__" else '_ybcore_tcr_epitope_35c38a8b70d4e403'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_35c38a8b70d4e403', '__yb_builtins_35c38a8b70d4e403']})
