"""Public interface to the native implementation."""
# Native core SHA256: a822f22356bd16758d39aaacce5c1f4bd84c084d2a4b5c5d5fc6bb66e94c0607
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_find_conserved_3691255ac09a20ce'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_3691255ac09a20ce', '__yb_builtins_3691255ac09a20ce']})
