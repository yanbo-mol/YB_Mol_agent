"""Public interface to the native implementation."""
# Native core SHA256: 503f68f6effc3dd17439ab26906e51bc3822f8fb657668a04c0a9c2342157d64
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_gap_analysis_bed416bb707f0ca0'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_bed416bb707f0ca0', '__yb_builtins_bed416bb707f0ca0']})
