"""Public interface to the native implementation."""
# Native core SHA256: 25c4fea137584d5412f10f43d97c277e0da4366f05b385da25a96f3dc14d448b
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_consensus_sequence_4d2cf25a0ec1edda'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_4d2cf25a0ec1edda', '__yb_builtins_4d2cf25a0ec1edda']})
