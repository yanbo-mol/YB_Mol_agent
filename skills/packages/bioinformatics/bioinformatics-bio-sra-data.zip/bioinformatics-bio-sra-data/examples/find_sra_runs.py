"""Public interface to the native implementation."""
# Native core SHA256: 0cdcd267d1957acef532012766a6328d874587a50fa06869f509fa22710bea19
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_find_sra_runs_66431d7c98a4dcab'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_66431d7c98a4dcab', '__yb_builtins_66431d7c98a4dcab']})
