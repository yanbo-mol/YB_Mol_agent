"""Public interface to the native implementation."""
# Native core SHA256: c1ecd0b02e1b79cf93416806b0b2318605869a8d54d3f9d1af6956f52f7c4018
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_scatac_workflow_66ec08727e61de47'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_66ec08727e61de47', '__yb_builtins_66ec08727e61de47']})
