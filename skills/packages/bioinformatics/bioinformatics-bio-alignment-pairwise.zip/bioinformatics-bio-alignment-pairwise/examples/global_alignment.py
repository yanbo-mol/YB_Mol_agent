"""Public interface to the native implementation."""
# Native core SHA256: dcaad2234405f730a2ce3ae367e4a7edaa42be5ec0b01c50bbb659180cd0a06a
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_global_alignment_dcbce70b8339480a'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_dcbce70b8339480a', '__yb_builtins_dcbce70b8339480a']})
