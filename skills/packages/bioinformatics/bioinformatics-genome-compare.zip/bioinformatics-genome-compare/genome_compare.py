"""Public interface to the native implementation."""
# Native core SHA256: a8335e70c280cafcd4ca33a076a9b6d3b8ad7a077ea9d443e42b216da3ad59a4
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_genome_compare_616b21afffeb80dd' if __name__ == "__main__" else '_ybcore_genome_compare_616b21afffeb80dd'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_616b21afffeb80dd', '__yb_builtins_616b21afffeb80dd']})
