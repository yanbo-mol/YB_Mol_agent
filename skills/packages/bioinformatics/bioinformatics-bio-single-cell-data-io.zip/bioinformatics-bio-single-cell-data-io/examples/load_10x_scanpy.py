"""Public interface to the native implementation."""
# Native core SHA256: 5fc9fd991b23c24ac08b8d9dc72408aac92413fa40e1909b38b37fb7e6a8f29e
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_load_10x_scanpy_7b471c4c17aea2ca'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_7b471c4c17aea2ca', '__yb_builtins_7b471c4c17aea2ca']})
