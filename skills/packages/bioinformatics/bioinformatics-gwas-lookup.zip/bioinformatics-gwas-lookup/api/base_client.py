"""Public interface to the native implementation."""
# Native core SHA256: f3eda97057f61b8b060364a914cbd709519711b581ff2f00c1c1b967339708f9
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_base_client_5a4280b0db177d8d'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_5a4280b0db177d8d', '__yb_builtins_5a4280b0db177d8d']})
