"""Public interface to the native implementation."""
# Native core SHA256: 1c78340e2af5d7069eb2fa515a51c07ed4ac7435d2a92d4be7be6f0750d9c42f
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_pheweb_bbj_0372531b148cb0b1'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_0372531b148cb0b1', '__yb_builtins_0372531b148cb0b1']})
