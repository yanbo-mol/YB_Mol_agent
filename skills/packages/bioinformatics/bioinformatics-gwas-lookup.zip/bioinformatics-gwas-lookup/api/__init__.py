"""Public interface to the native implementation."""
# Native core SHA256: 141339c0d8846e79e22ee059f2ff5db17e3d659c6ef39e6504445607a4de7484
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore___init___5a347e064cfaf948'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_5a347e064cfaf948', '__yb_builtins_5a347e064cfaf948']})
