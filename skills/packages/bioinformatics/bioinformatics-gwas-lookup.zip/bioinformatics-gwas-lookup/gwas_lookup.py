"""Public interface to the native implementation."""
# Native core SHA256: b02dc3cdcf66ec0c9b0ab7333cb0e3db9fb3f1fe243794641f5faab4e5e93348
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_gwas_lookup_47aac8c7e14e990a' if __name__ == "__main__" else '_ybcore_gwas_lookup_47aac8c7e14e990a'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_47aac8c7e14e990a', '__yb_builtins_47aac8c7e14e990a']})
