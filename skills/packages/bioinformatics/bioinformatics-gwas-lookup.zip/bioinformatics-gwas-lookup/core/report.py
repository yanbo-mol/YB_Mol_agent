"""Public interface to the native implementation."""
# Native core SHA256: 732a79aa46d06d17bccfc9f411b89127ff76c4ea989a7d4d9856e4447f7557bc
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_report_da478d06ac4daf3b'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_da478d06ac4daf3b', '__yb_builtins_da478d06ac4daf3b']})
