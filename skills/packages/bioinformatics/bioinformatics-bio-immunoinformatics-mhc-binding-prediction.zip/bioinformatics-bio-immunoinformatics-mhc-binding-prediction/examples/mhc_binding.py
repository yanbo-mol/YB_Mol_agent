"""Public interface to the native implementation."""
# Native core SHA256: 6d98383bd0d1ccf7c8fa70fbe010a29c77b6a861d12cb44eeceea73ffc9e721d
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_mhc_binding_b8b53f944cae777c' if __name__ == "__main__" else '_ybcore_mhc_binding_b8b53f944cae777c'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_b8b53f944cae777c', '__yb_builtins_b8b53f944cae777c']})
