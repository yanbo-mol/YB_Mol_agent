"""Public interface to the native implementation."""
# Native core SHA256: 9412b7b505cd6d3b13b71658cb0081fa0d68a22ee0905bf2d210fd605ac794cc
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_cassiopeia_reconstruction_409dce19402afb90'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_409dce19402afb90', '__yb_builtins_409dce19402afb90']})
