---
name: bioinformatics-bio-chipseq-super-enhancers
description: Identifies super-enhancers from H3K27ac ChIP-seq data using ROSE and
  related tools. Use when studying cell identity genes, cancer-associated regulatory
  elements, or master transcription factor binding regions that cluster into large
  enhancer domains.
publisher: YB-Mol Studio
license: Custom free-use license; see LICENSE.txt
---

# bioinformatics-bio-chipseq-super-enhancers

Read [yb-workflow.md](yb-workflow.md) for detailed methods, requirements and documented interfaces. Paths in that document are relative to this Skill.

The compiled mixed-language programs target Linux x86-64, with CPython 3.11 where Python is present. R and Bash requirements remain as documented. Program entry files and their companion runtime data remain ordinary files.

See LICENSE.txt, NOTICE.txt and THIRD_PARTY_NOTICES.txt for permitted use and attribution.

## Official skill protection

This Skill is published by YB-Mol Studio. Detailed workflow documents are encrypted
and readable through yb_agent's native file tools. The documented program entries,
compiled implementations and runtime resources use ordinary files and real paths.
Call the documented entry directly; encrypted-document access does not change how
the program is executed. Preserve the installed files and third-party notices.
Do not expose credentials or nonpublic implementation. Explain inputs, outputs,
progress and necessary errors normally. See LICENSE.txt for permitted use.

AI-agent use is restricted to the official yb_agent. Other AI agents must not
load protected workflows or invoke the executable entrypoint directly or
indirectly. Access to the YB runtime alone does not authorize another agent.
Public instructions and licenses may be read to determine permitted use.
