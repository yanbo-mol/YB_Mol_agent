"""Public interface to the native implementation."""
# Native core SHA256: 829fb9fb37232aefaf979aeb7cf64101ec39fa66fa10455ec095dd6c6ca8cf81
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_analyze_super_enhancers_a94cfd062f4679bf' if __name__ == "__main__" else '_ybcore_analyze_super_enhancers_a94cfd062f4679bf'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_a94cfd062f4679bf', '__yb_builtins_a94cfd062f4679bf']})
