"""Public interface to the native implementation."""
# Native core SHA256: da6d872c72a8beca3e6cf7c87c5448eae339e32eca6cafd76d0c4ee7c2d2453e
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_batch_amr_screening_ed9cade62ad14c25' if __name__ == "__main__" else '_ybcore_batch_amr_screening_ed9cade62ad14c25'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_ed9cade62ad14c25', '__yb_builtins_ed9cade62ad14c25']})
