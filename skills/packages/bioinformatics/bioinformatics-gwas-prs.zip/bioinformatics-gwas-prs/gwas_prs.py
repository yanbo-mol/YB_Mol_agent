"""Public interface to the native implementation."""
# Native core SHA256: ad5e0309476918b20a05d51df737e0f3a8c8aabacaa6b1b92811b43376e57c88
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_gwas_prs_28655945f4f7952e' if __name__ == "__main__" else '_ybcore_gwas_prs_28655945f4f7952e'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_28655945f4f7952e', '__yb_builtins_28655945f4f7952e']})
