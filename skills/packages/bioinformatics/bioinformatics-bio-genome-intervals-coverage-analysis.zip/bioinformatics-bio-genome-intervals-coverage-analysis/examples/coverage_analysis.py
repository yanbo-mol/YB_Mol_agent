"""Public interface to the native implementation."""
# Native core SHA256: e51abc75aa64bed190899a9af7153ae7c0240031c11354d3abac5ed8c813c6db
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_coverage_analysis_3af84fd41fea0a29'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_3af84fd41fea0a29', '__yb_builtins_3af84fd41fea0a29']})
