"""Public interface to the native implementation."""
# Native core SHA256: f01012f70af2f0ecf623abd7eb65c5dcb848ce2649dbc7dcc5b8bf71b5298904
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_lime_explanation_a5d8b1d392fd7d30'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_a5d8b1d392fd7d30', '__yb_builtins_a5d8b1d392fd7d30']})
