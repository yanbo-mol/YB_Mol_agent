"""Public interface to the native implementation."""
# Native core SHA256: 92a87c08a1bb821473ccda2fee49ad2289005dddab94e96dfc2eb7bf8a04c7ed
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_immunogenicity_scoring_296e268097c368e5' if __name__ == "__main__" else '_ybcore_immunogenicity_scoring_296e268097c368e5'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_296e268097c368e5', '__yb_builtins_296e268097c368e5']})
