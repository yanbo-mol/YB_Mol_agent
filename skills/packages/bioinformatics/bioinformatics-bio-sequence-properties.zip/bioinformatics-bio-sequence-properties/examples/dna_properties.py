"""Public interface to the native implementation."""
# Native core SHA256: ffde6837fd96bbeb9e0c0217799a172f7e80f54882e4e081d4a9095d16106cfa
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_dna_properties_23cd45b8047d2a28'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_23cd45b8047d2a28', '__yb_builtins_23cd45b8047d2a28']})
