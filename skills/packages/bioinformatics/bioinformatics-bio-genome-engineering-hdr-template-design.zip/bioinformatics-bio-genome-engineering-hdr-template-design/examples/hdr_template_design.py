"""Public interface to the native implementation."""
# Native core SHA256: 1c8e6e45647a086e29c52d621bfb107edeb0249cf52e4ad74196e16723f91696
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_hdr_template_design_397d9acbba18c0bf' if __name__ == "__main__" else '_ybcore_hdr_template_design_397d9acbba18c0bf'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_397d9acbba18c0bf', '__yb_builtins_397d9acbba18c0bf']})
