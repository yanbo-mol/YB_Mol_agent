"""Public interface to the native implementation."""
# Native core SHA256: 7b4240c187b760f2f890137cfc6a3b17e4061fb50b8d28ba432be1c4e106bbc2
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_search_geo_d76bf1005868982a'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_d76bf1005868982a', '__yb_builtins_d76bf1005868982a']})
