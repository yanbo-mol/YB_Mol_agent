"""Public interface to the native implementation."""
# Native core SHA256: d81eb4dedb4e5350ba3fe07845f5d27aa6ed12b056e0c93c1097155bee53ea16
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_geo_to_sra_f39d5dba46710b6b'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_f39d5dba46710b6b', '__yb_builtins_f39d5dba46710b6b']})
