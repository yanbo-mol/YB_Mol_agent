"""Public interface to the native implementation."""
# Native core SHA256: 83b77923c4dbc2f9bc48f0a7477091fd8ae41159f1ba2043bba20c67227b4424
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_biomarker_signature_studio_dfe009edee4f1292' if __name__ == "__main__" else '_ybcore_biomarker_signature_studio_dfe009edee4f1292'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_dfe009edee4f1292', '__yb_builtins_dfe009edee4f1292']})
