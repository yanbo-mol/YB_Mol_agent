"""Public interface to the native implementation."""
# Native core SHA256: bc104835de2999bfa96746f7b473e0e51e8dce69b4bca9d5fcc99afb18744267
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_measure_distance_d8b76d98386cdb01'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_d8b76d98386cdb01', '__yb_builtins_d8b76d98386cdb01']})
