"""Public interface to the native implementation."""
# Native core SHA256: 144a217b9f44915b4e6d3a22732c21a4e97ecb94c5f67a9cdb9b82b68a2c1a8a
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_find_contacts_6dd517327125e8ce'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_6dd517327125e8ce', '__yb_builtins_6dd517327125e8ce']})
