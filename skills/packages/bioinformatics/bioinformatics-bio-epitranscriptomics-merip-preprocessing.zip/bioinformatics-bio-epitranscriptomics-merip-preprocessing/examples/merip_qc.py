"""Public interface to the native implementation."""
# Native core SHA256: f267977f77d6df98fce2e50a2eb4500b89d3708590cbd577c7800026fa0a8412
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_merip_qc_3ac4d5e60f1bcb72' if __name__ == "__main__" else '_ybcore_merip_qc_3ac4d5e60f1bcb72'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_3ac4d5e60f1bcb72', '__yb_builtins_3ac4d5e60f1bcb72']})
