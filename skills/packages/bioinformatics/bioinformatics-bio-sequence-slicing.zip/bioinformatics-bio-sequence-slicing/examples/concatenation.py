"""Public interface to the native implementation."""
# Native core SHA256: dcc2972f218c4f61fb417377a80632e8edf14e8217833015e36b8fb1f575223a
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_concatenation_aa7c87fbc677b502'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_aa7c87fbc677b502', '__yb_builtins_aa7c87fbc677b502']})
