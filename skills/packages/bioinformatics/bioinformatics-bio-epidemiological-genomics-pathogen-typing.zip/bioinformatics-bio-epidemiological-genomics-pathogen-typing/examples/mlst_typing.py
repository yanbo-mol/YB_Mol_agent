"""Public interface to the native implementation."""
# Native core SHA256: a219a8723fdc9979a957e3afbc9d7360c531f88cfba79c678ebccf05a57a0bd9
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_mlst_typing_711be560f811675f' if __name__ == "__main__" else '_ybcore_mlst_typing_711be560f811675f'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_711be560f811675f', '__yb_builtins_711be560f811675f']})
