"""Public interface to the native implementation."""
# Native core SHA256: 82d8d17fb7a264104b5e73b0c7eed22f1bb03ee54a6da2c8107424416e2f3fdf
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_universal_annotator_e45fb79e978df0be' if __name__ == "__main__" else '_ybcore_universal_annotator_e45fb79e978df0be'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_e45fb79e978df0be', '__yb_builtins_e45fb79e978df0be']})
