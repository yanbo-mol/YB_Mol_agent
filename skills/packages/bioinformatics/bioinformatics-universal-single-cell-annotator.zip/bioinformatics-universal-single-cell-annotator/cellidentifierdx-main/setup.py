"""Public interface to the native implementation."""
# Native core SHA256: 65815ec1b63cfef1e5c2fed3675451d90447a38bd37a5e7c6c20592548c2ec14
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_setup_3b9d124cb9c220be'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_3b9d124cb9c220be', '__yb_builtins_3b9d124cb9c220be']})
