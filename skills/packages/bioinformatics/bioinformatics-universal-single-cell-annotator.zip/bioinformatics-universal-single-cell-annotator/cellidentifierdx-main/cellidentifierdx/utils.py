"""Public interface to the native implementation."""
# Native core SHA256: 280830dc4e25a7c7c65050642597c4473606879ec3550f069d7fc0b4c8c06913
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_utils_a710828e8592ccbe'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_a710828e8592ccbe', '__yb_builtins_a710828e8592ccbe']})
