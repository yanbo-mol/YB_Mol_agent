"""Public interface to the native implementation."""
# Native core SHA256: 3b4d6cfefd1384fdb2e65268dccd38840558da887825925f361b9a22a9a8bdc4
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_scoring_01579c1b5f72c383'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_01579c1b5f72c383', '__yb_builtins_01579c1b5f72c383']})
