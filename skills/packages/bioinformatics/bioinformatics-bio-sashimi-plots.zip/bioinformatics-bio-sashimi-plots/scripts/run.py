"""Public entry point for a protected YB-Mol Studio skill."""
from pathlib import Path
from yb_agent.protected_skills import run_protected_skill

if __name__ == "__main__":
    raise SystemExit(run_protected_skill(Path(__file__).resolve().parent.parent))
