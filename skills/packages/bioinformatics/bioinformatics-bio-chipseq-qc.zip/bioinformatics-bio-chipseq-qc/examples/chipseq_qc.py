"""Public interface to the native implementation."""
# Native core SHA256: 1d051ebd48de988fe2ef2156ce8a25ea557ed12bbd57bc45364a87da9d3e642a
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_chipseq_qc_09cf4f541dbe2bd9' if __name__ == "__main__" else '_ybcore_chipseq_qc_09cf4f541dbe2bd9'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_09cf4f541dbe2bd9', '__yb_builtins_09cf4f541dbe2bd9']})
