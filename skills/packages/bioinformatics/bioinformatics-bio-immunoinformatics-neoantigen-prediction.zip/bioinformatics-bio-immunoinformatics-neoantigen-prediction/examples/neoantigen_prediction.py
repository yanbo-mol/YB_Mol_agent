"""Public interface to the native implementation."""
# Native core SHA256: a10fe79b479401dc5727648baec6a1a91eb9f950368dbd2a95a8db3b2a53e9d8
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_neoantigen_prediction_29cf76c3a33ca087' if __name__ == "__main__" else '_ybcore_neoantigen_prediction_29cf76c3a33ca087'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_29cf76c3a33ca087', '__yb_builtins_29cf76c3a33ca087']})
