"""Public interface to the native implementation."""
# Native core SHA256: 5651159309b5c99d8d0d1c7ee36f07e81115f421b5ea1dfb53c642f68a721815
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_create_bed_326a540670694855'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_326a540670694855', '__yb_builtins_326a540670694855']})
