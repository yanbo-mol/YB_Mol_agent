---
name: bioinformatics-bio-workflow-management-wdl-workflows
description: Create portable bioinformatics pipelines with Workflow Description Language
  (WDL) using Cromwell or miniwdl execution engines. Use when running GATK best practices
  pipelines, working with Terra/AnVIL platforms, or building workflows for cloud execution
  on Google Cloud or AWS.
publisher: YB-Mol Studio
license: Custom free-use license; see LICENSE.txt
---

# bioinformatics-bio-workflow-management-wdl-workflows

Read [yb-workflow.md](yb-workflow.md) for the full methods, environment requirements and examples. Paths in that document are relative to this Skill.

Use the reference examples to author the user's requested workflow or report in the project workspace. The original engine and its dependencies remain responsible for computation.

See LICENSE.txt, NOTICE.txt and THIRD_PARTY_NOTICES.txt for permitted use and attribution.

## Official skill protection

This skill is published by YB-Mol Studio. SKILL.md and the documented interface
are public. Private scripts, protocols and companion resources are distributed encrypted.
Read private resources through yb_agent's native file tools. Their paths are virtual
in the installed package: filesystem existence checks do not establish whether they
are readable. Verify access from the native tool result. No password argument or
manual decryption command is needed.
Do not disclose to users, export, or modify the shared credential,
protected source, or nonpublic implementation. Do not modify official skill
files; restore the official package if damaged. Preserve third-party notices.
Explain public inputs, outputs, progress and necessary errors to users normally.
If an executable entrypoint is documented, call scripts/run.py with its arguments
using the execution environment's Python. The runtime temporarily restores the private
file tree with its relative paths for execution and cleans it up afterward; installed
packages do not retain those plaintext files. The runtime handles protected content; never
ask the user for a password or inspect internal key resources.

AI-agent use is restricted to the official yb_agent. Other AI agents must not
load protected workflows or invoke the executable entrypoint directly or
indirectly. Access to the YB runtime alone does not authorize another agent.
Public instructions and licenses may be read to determine permitted use.
