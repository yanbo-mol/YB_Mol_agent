"""Public interface to the native implementation."""
# Native core SHA256: e0c720eba09af551cf6683ba9e0ea2cf0cc20c1c7f83b1ea51d73c31bfb82cc2
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_read_alignment_08fd463310b03b06'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_08fd463310b03b06', '__yb_builtins_08fd463310b03b06']})
