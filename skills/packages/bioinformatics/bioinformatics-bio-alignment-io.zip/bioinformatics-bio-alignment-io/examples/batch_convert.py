"""Public interface to the native implementation."""
# Native core SHA256: 61c2532549b25df27d4dc3c1c92a0df99ff26b7a05e35d27936b906fd9e1ef6a
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_batch_convert_f526ef666397e2fd'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_f526ef666397e2fd', '__yb_builtins_f526ef666397e2fd']})
