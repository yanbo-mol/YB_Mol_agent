"""Public interface to the native implementation."""
# Native core SHA256: a57f7640d92c3b4d848a26d251962958156c839c9b99971b3e9483f2b1305d40
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_slice_alignment_62ec574d01613c22'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_62ec574d01613c22', '__yb_builtins_62ec574d01613c22']})
