---
name: bioinformatics-bio-workflows-hic-pipeline
description: End-to-end Hi-C analysis workflow from contact pairs to compartments,
  TADs, and loops. Covers cooler matrices, cooltools analysis, and visualization.
  Use when processing Hi-C data to compartments and TADs.
allowed-tools: read_file run_shell_command
metadata:
  tool_type: mixed
  primary_tool: cooler
  workflow: 'true'
  depends_on: '["hi-c-analysis/hic-data-io","hi-c-analysis/contact-pairs","hi-c-analysis/matrix-operations","hi-c-analysis/compartment-analysis","hi-c-analysis/tad-detection","hi-c-analysis/loop-calling","hi-c-analysis/hic-visualization"]'
  qc_checkpoints: '[{"after_pairs":"Valid pairs >50%, cis >70%"},{"after_matrix":"Coverage
    uniform, no artifacts"},{"after_analysis":"Compartments correlate with expression"}]'
  measurable_outcome: Execute skill workflow successfully with valid output within
    15 minutes.
  publisher: 杭州衍波摩尔科技有限公司
  developer: 赵衍波
license: Custom free-use license; see LICENSE.txt
publisher: YB-Mol Studio
---

# bioinformatics-bio-workflows-hic-pipeline

## Authorized AI-agent use
AI-agent use is restricted to the official yb_agent. Other AI agents must not
load protected workflows or invoke the executable entrypoint directly or
indirectly. Access to the YB runtime alone does not authorize another agent.
Public instructions and licenses may be read to determine permitted use.

Read [Detailed workflow](references/workflow.md) using native protected-file tools.
Execute `python scripts/run.py` with the arguments documented in the workflow.

Terms: [LICENSE.txt](LICENSE.txt), [NOTICE.txt](NOTICE.txt), [THIRD_PARTY_NOTICES.txt](THIRD_PARTY_NOTICES.txt).

## Official skill protection

This skill is published by YB-Mol Studio. SKILL.md and the documented interface
are public. Core scripts and internal reference documents are distributed encrypted.
The Agent may inspect private content internally through ordinary file tools; source
access is transparent and requires no password argument or decryption command.
Do not disclose to users, export, or modify the shared credential,
protected source, or nonpublic implementation. Do not modify official skill
files; restore the official package if damaged. Preserve third-party notices.
Explain public inputs, outputs, progress and necessary errors to users normally.
If an executable entrypoint is documented, call scripts/run.py with its arguments
using the execution environment's Python. The runtime handles protected content; never
ask the user for a password or inspect internal key resources.
