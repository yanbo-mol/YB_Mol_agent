"""Public interface to the native implementation."""
# Native core SHA256: 9ec85755c3f885d3f372b6d7b7af69dd6ed57f714491e8c450c3fbd57352fb34
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_read_newick_9397dedc9ca806bb'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_9397dedc9ca806bb', '__yb_builtins_9397dedc9ca806bb']})
