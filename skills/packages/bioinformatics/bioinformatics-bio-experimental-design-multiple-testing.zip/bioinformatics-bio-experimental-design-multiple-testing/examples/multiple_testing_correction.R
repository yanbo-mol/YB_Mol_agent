compiler::loadcmp(local({
  frames <- sys.frames()
  paths <- lapply(frames, function(f) f$ofile)
  paths <- Filter(function(x) !is.null(x) && length(x)==1L, paths)
  if (length(paths)) this_file <- tail(paths,1)[[1]] else {
    a <- grep("^--file=",commandArgs(),value=TRUE)
    if (!length(a)) stop("Cannot locate compiled R entry")
    this_file <- sub("^--file=","",a[[1]])
  }
  paste0(normalizePath(this_file,mustWork=TRUE),"c")
}), envir=environment(), chdir=FALSE)
