"""Public interface to the native implementation."""
# Native core SHA256: 24e1d5a378e563ee45c586e11e393a5b41d097ec566ba5b7ed15b1a484906144
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_substitution_counts_5cf09e5deb8efeab'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_5cf09e5deb8efeab', '__yb_builtins_5cf09e5deb8efeab']})
