"""Public interface to the native implementation."""
# Native core SHA256: 6481cad3fee851eff5dddfed3ab42703d71f509a8d5b2197e2ec033e83a09f4b
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_entropy_analysis_e09e38ced0ca88d1'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_e09e38ced0ca88d1', '__yb_builtins_e09e38ced0ca88d1']})
