"""Public interface to the native implementation."""
# Native core SHA256: d29e9015bc5142f3a9b266cf8b3ed93c6a26d4cc5d5cb840a57a58f9da318071
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_conservation_profile_4dcf7aaf10978081'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_4dcf7aaf10978081', '__yb_builtins_4dcf7aaf10978081']})
