"""Public interface to the native implementation."""
# Native core SHA256: e21858b8a1c2cb36a0bdedc92374ea122b737ef05c74b52239bd92771bf99050
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_crispr_editing_workflow_ca50dfffb1366ee6' if __name__ == "__main__" else '_ybcore_crispr_editing_workflow_ca50dfffb1366ee6'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_ca50dfffb1366ee6', '__yb_builtins_ca50dfffb1366ee6']})
