"""Public interface to the native implementation."""
# Native core SHA256: c267f76ca5bb86bdc1eda301d055887fc7b033dade58fbb989f121f7c3e97b29
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_harmony_integration_ffc701c8f0b43aea' if __name__ == "__main__" else '_ybcore_harmony_integration_ffc701c8f0b43aea'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_ffc701c8f0b43aea', '__yb_builtins_ffc701c8f0b43aea']})
