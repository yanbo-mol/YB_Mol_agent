"""Public interface to the native implementation."""
# Native core SHA256: c79ad346b227653715a14b10e53bba61441ce25eeb9fb36d7fc8663077454f0a
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_common_ancestor_8e1e9d6c0e18ff61'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_8e1e9d6c0e18ff61', '__yb_builtins_8e1e9d6c0e18ff61']})
