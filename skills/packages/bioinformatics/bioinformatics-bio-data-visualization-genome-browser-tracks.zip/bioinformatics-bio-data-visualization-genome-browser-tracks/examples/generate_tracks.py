"""Public interface to the native implementation."""
# Native core SHA256: 5f4093feec3a8a42af4bae813852f1d341368ee2215b4fb6463234ccc0240579
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_generate_tracks_1ab2f49e3e343556' if __name__ == "__main__" else '_ybcore_generate_tracks_1ab2f49e3e343556'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_1ab2f49e3e343556', '__yb_builtins_1ab2f49e3e343556']})
