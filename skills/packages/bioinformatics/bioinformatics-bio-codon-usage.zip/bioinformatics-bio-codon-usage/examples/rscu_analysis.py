"""Public interface to the native implementation."""
# Native core SHA256: 52dc91a97b451d603c471d766a5e7aa3ca4f8a7cf4a7a9ccab60dd188f21a572
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_rscu_analysis_78b69fdda753c51b'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_78b69fdda753c51b', '__yb_builtins_78b69fdda753c51b']})
