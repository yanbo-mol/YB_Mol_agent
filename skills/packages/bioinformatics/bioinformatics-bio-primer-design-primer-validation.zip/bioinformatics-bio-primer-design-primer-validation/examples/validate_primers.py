"""Public interface to the native implementation."""
# Native core SHA256: d0b15210275a72e8886755252bf7ac99b147053a851d0eae7ff0732229b69fd8
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_validate_primers_6279dfd22f088e1c'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_6279dfd22f088e1c', '__yb_builtins_6279dfd22f088e1c']})
