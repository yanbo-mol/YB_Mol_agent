"""Public interface to the native implementation."""
# Native core SHA256: 54f9dcce7b971f8bbf6cef3885ab49b3dc917f90db3e7e11f732c5e514404db2
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_amr_surveillance_1bf0f3ed5d618744' if __name__ == "__main__" else '_ybcore_amr_surveillance_1bf0f3ed5d618744'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_1bf0f3ed5d618744', '__yb_builtins_1bf0f3ed5d618744']})
