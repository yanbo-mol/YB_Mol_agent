"""Public interface to the native implementation."""
# Native core SHA256: af76bc406257d5279bc7acaf3605bc388631583b92ef5ec3e89a326e1fd392a1
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_orf_finding_66202442f9a73b8e'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_66202442f9a73b8e', '__yb_builtins_66202442f9a73b8e']})
