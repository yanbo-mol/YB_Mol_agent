"""Public interface to the native implementation."""
# Native core SHA256: 6358a8b1edb80a57ff5c3d7c00750cc387185d6346b46ba92cc711c8583f5473
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_off_target_analysis_5be2fd749955b98c' if __name__ == "__main__" else '_ybcore_off_target_analysis_5be2fd749955b98c'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_5be2fd749955b98c', '__yb_builtins_5be2fd749955b98c']})
