"""Public interface to the native implementation."""
# Native core SHA256: cbcbad1c1add46633fcbf8ad88e6c58443773c8f447d6f431397ae72f9ade55e
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_cox_regression_2879e255da7e2280'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_2879e255da7e2280', '__yb_builtins_2879e255da7e2280']})
