"""Public interface to the native implementation."""
# Native core SHA256: 342ead5619665d8abaf338704ed67f7928a7363737413b3ac9828a1f5614c7ae
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_kaplan_meier_1bb1a1aa3da0251f'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_1bb1a1aa3da0251f', '__yb_builtins_1bb1a1aa3da0251f']})
