"""Public interface to the native implementation."""
# Native core SHA256: 5e1454c2400c56d0ef13400ce48f88ae4c4e62be5459d02f383febdbb9a8297e
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_esmfold_api_1e6e5140520be3d8' if __name__ == "__main__" else '_ybcore_esmfold_api_1e6e5140520be3d8'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_1e6e5140520be3d8', '__yb_builtins_1e6e5140520be3d8']})
