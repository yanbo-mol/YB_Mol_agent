"""Public interface to the native implementation."""
# Native core SHA256: c1d9049523316a8e0d069bf9b2548aba0db7ef74e0dfcd1a4da1b7a004f3fa0d
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_parse_pdb_2603ea3ac16e3316'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_2603ea3ac16e3316', '__yb_builtins_2603ea3ac16e3316']})
