"""Public interface to the native implementation."""
# Native core SHA256: b95ba470ec33aac31c68aaeeed9e07cf9e7766c16805d3e4163977a00e92333c
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_genbank_features_bb71296089695fdb'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_bb71296089695fdb', '__yb_builtins_bb71296089695fdb']})
