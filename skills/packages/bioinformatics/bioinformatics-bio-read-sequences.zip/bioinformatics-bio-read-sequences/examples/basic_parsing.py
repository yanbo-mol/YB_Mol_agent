"""Public interface to the native implementation."""
# Native core SHA256: 21d0318a345f54581d093cdba5e73569bceb4bde4aad4c1c99dd08b688ea17f8
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_basic_parsing_f3d573924383345d'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_f3d573924383345d', '__yb_builtins_f3d573924383345d']})
