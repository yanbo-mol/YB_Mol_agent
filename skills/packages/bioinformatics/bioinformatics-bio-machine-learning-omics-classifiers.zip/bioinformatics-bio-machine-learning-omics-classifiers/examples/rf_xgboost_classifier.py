"""Public interface to the native implementation."""
# Native core SHA256: cee0531bc68505995c81a4fab08efbb382d863f8c7a917e9145e0780f6aaefa5
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_rf_xgboost_classifier_bc99ac486bb917c6'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_bc99ac486bb917c6', '__yb_builtins_bc99ac486bb917c6']})
