"""Public interface to the native implementation."""
# Native core SHA256: 5c5993ca623f4fdb884b62cad520a5322da3d9f1766e952ab2b59df282c29b18
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_logistic_regression_699fb56055b26f0d'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_699fb56055b26f0d', '__yb_builtins_699fb56055b26f0d']})
