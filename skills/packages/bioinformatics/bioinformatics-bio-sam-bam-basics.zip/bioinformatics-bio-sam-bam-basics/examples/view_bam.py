"""Public interface to the native implementation."""
# Native core SHA256: 96dc1686952f169d6ad68a66f7b1dfb23b4a6f09e4a5e0d84027f118c4f2541d
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_view_bam_0d96ea80261aad38' if __name__ == "__main__" else '_ybcore_view_bam_0d96ea80261aad38'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_0d96ea80261aad38', '__yb_builtins_0d96ea80261aad38']})
