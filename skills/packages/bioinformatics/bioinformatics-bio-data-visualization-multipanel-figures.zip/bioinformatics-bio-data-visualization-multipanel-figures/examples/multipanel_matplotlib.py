"""Public interface to the native implementation."""
# Native core SHA256: 2b135811908c7d3daf963056dbdd0d3d5f03be021dd49c42d4a711f190fe81e7
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_multipanel_matplotlib_2ee55edc6d9525b4'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_2ee55edc6d9525b4', '__yb_builtins_2ee55edc6d9525b4']})
