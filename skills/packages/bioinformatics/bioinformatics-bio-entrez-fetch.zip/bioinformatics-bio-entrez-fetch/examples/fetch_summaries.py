"""Public interface to the native implementation."""
# Native core SHA256: 41a159abe99c25e5589368b66a9520d26a26f7b1056c1307c3ead0283eb851dc
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_fetch_summaries_39acc607e1c01761'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_39acc607e1c01761', '__yb_builtins_39acc607e1c01761']})
