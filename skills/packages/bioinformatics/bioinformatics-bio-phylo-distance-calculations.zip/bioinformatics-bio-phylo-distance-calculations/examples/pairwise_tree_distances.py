"""Public interface to the native implementation."""
# Native core SHA256: c9a0837613ea3ec3a03b6db24d76ae7dd8e55a8dfd08cc7b5488a7b1b931be85
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_pairwise_tree_distances_58a78e2904d1d49b'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_58a78e2904d1d49b', '__yb_builtins_58a78e2904d1d49b']})
