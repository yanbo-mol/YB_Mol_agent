"""Public interface to the native implementation."""
# Native core SHA256: 7d64608d9e1cd7c195862a317b081788a16c7364b39822518311cbf3f44786ec
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_basic_tree_plot_91c72137bf9813a1'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_91c72137bf9813a1', '__yb_builtins_91c72137bf9813a1']})
