"""Public interface to the native implementation."""
# Native core SHA256: a437d40cec81386f55dff4f4f8aec89222787b2c698f862b6b26ca695f991328
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_extract_sequence_fbf31a1ce3e771c0'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_fbf31a1ce3e771c0', '__yb_builtins_fbf31a1ce3e771c0']})
