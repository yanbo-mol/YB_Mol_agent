---
name: bioinformatics-bio-epidemiological-genomics-phylodynamics
description: Construct time-scaled phylogenies and infer evolutionary dynamics using
  TreeTime and BEAST2 for outbreak analysis. Estimate divergence times, molecular
  clock rates, and ancestral states. Use when dating outbreak origins, estimating
  transmission rates, or building time-calibrated trees.
publisher: YB-Mol Studio
license: Custom free-use license; see LICENSE.txt
---

# bioinformatics-bio-epidemiological-genomics-phylodynamics

Read [yb-workflow.md](yb-workflow.md) for detailed methods, requirements and documented interfaces. Paths in that document are relative to this Skill.

Compiled Python entries use CPython 3.11 on Windows x86-64. Program entry files and their companion runtime data remain ordinary files.

See LICENSE.txt, NOTICE.txt and THIRD_PARTY_NOTICES.txt for permitted use and attribution.

## Official skill protection

This Skill is published by YB-Mol Studio. Detailed workflow documents are encrypted
and readable through yb_agent's native file tools. The documented program entries,
compiled implementations and runtime resources use ordinary files and real paths.
Call the documented entry directly; encrypted-document access does not change how
the program is executed. Preserve the installed files and third-party notices.
Do not expose credentials or nonpublic implementation. Explain inputs, outputs,
progress and necessary errors normally. See LICENSE.txt for permitted use.

AI-agent use is restricted to the official yb_agent. Other AI agents must not
load protected workflows or invoke the executable entrypoint directly or
indirectly. Access to the YB runtime alone does not authorize another agent.
Public instructions and licenses may be read to determine permitted use.
