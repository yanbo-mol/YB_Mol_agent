"""Plaintext authoring entry; encrypted distribution uses the native YB wrapper."""
from main import execute, main

if __name__ == '__main__':
    raise SystemExit(main())
