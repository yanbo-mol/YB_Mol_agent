"""Public interface to the native implementation."""
# Native core SHA256: 6b4831bc49935feb33e0e6e4d4a0ebc1a04aecb9ef1a5630b6ef9616026d2c93
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_test_protein_tools_dc6830d8da29dc22' if __name__ == "__main__" else '_ybcore_test_protein_tools_dc6830d8da29dc22'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_dc6830d8da29dc22', '__yb_builtins_dc6830d8da29dc22']})
