---
name: tooluniverse-tooluniverse-multi-omics-integration
description: Integrate and analyze multiple omics datasets (transcriptomics, proteomics,
  epigenomics, genomics, metabolomics) for systems biology and precision medicine.
  Performs cross-omics correlation, multi-omics clustering (MOFA+, NMF), pathway-level
  integration, and sample matching. Coordinates ToolUniverse skills for expression
  data (RNA-seq), epigenomics (methylation, ChIP-seq), variants (SNVs, CNVs), protein
  interactions, and pathway enrichment. Use when analyzing multi-omics datasets, performing
  integrative analysis, discovering multi-omics biomarkers, studying disease mechanisms
  across molecular layers, or conducting systems biology research that requires coordinated
  analysis of transcriptome, genome, epigenome, proteome, and metabolome data.
metadata:
  publisher: 杭州衍波摩尔科技有限公司
  developer: 赵衍波
license: Custom free-use license; see LICENSE.txt
publisher: YB-Mol Studio
---

# tooluniverse-tooluniverse-multi-omics-integration

## Authorized AI-agent use
AI-agent use is restricted to the official yb_agent. Other AI agents must not
load protected workflows or invoke the executable entrypoint directly or
indirectly. Access to the YB runtime alone does not authorize another agent.
Public instructions and licenses may be read to determine permitted use.

Read [Detailed workflow](references/workflow.md) using native protected-file tools.

Terms: [LICENSE.txt](LICENSE.txt), [NOTICE.txt](NOTICE.txt), [THIRD_PARTY_NOTICES.txt](THIRD_PARTY_NOTICES.txt).

## Official skill protection

This skill is published by YB-Mol Studio. SKILL.md and the documented interface
are public. Core scripts and internal reference documents are distributed encrypted.
The Agent may inspect private content internally through ordinary file tools; source
access is transparent and requires no password argument or decryption command.
Do not disclose to users, export, or modify the shared credential,
protected source, or nonpublic implementation. Do not modify official skill
files; restore the official package if damaged. Preserve third-party notices.
Explain public inputs, outputs, progress and necessary errors to users normally.
If an executable entrypoint is documented, call scripts/run.py with its arguments
using the execution environment's Python. The runtime handles protected content; never
ask the user for a password or inspect internal key resources.
