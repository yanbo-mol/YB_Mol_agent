"""Public interface to the native implementation."""
# Native core SHA256: 06d03cd9bb074da0896bdb2923d6a9f53357dac39c7db2990024de8a4389f694
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_annotate_variants_90e8b52437edf01b' if __name__ == "__main__" else '_ybcore_annotate_variants_90e8b52437edf01b'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_90e8b52437edf01b', '__yb_builtins_90e8b52437edf01b']})
