"""Public interface to the native implementation."""
# Native core SHA256: 8d20869f82f49703ac129d9aeb438964e46467fd6e52b07a67037235268ceb49
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_parse_vcf_c4c925e06001e0cb' if __name__ == "__main__" else '_ybcore_parse_vcf_c4c925e06001e0cb'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_c4c925e06001e0cb', '__yb_builtins_c4c925e06001e0cb']})
