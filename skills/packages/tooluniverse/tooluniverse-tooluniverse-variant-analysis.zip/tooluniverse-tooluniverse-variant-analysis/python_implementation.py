"""Public interface to the native implementation."""
# Native core SHA256: 2935a48564733e4fbdb03b5fef2fdb31c3cb0b2fa88f30ab59eca6e539efe1ad
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_python_implementation_dbce49d06abcd277' if __name__ == "__main__" else '_ybcore_python_implementation_dbce49d06abcd277'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_dbce49d06abcd277', '__yb_builtins_dbce49d06abcd277']})
