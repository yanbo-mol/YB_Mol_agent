"""Public interface to the native implementation."""
# Native core SHA256: de02230fdc0b5cb8679c07413452f483f49cdf6c3604fd878c87b934c3fc3217
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_python_implementation_84318eab67416f55' if __name__ == "__main__" else '_ybcore_python_implementation_84318eab67416f55'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_84318eab67416f55', '__yb_builtins_84318eab67416f55']})
