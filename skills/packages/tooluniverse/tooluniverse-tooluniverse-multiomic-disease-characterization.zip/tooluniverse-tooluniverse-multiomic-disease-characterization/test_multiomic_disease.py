"""Public interface to the native implementation."""
# Native core SHA256: 16a6315e45d4393dc05e46d22f31f96d905322407a6d7e804e9deef94e5ce284
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_test_multiomic_disease_bc5b7fbaf5ded18d' if __name__ == "__main__" else '_ybcore_test_multiomic_disease_bc5b7fbaf5ded18d'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_bc5b7fbaf5ded18d', '__yb_builtins_bc5b7fbaf5ded18d']})
