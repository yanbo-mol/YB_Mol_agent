"""Public interface to the native implementation."""
# Native core SHA256: 11a31192642d1a7b53fcdf06251400e60e75650f9337789f2ffddde775b7ff41
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_test_gwas_snp_tools_simple_db51f057ba55deef'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_db51f057ba55deef', '__yb_builtins_db51f057ba55deef']})
