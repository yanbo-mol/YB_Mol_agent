"""Public interface to the native implementation."""
# Native core SHA256: 3fa9f898e2dbd8c1c11a88bdaff7dcb235cbe6adb92128a2ba29c5c9936765a7
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_test_skill_comprehensive_fb37463b113ecf7e' if __name__ == "__main__" else '_ybcore_test_skill_comprehensive_fb37463b113ecf7e'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_fb37463b113ecf7e', '__yb_builtins_fb37463b113ecf7e']})
