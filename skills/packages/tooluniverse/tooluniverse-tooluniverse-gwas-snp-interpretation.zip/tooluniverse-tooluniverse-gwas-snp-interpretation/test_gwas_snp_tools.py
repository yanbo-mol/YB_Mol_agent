"""Public interface to the native implementation."""
# Native core SHA256: 2860b61f5e0241ac394365cfd63633b437205e57a831b2c72ac561d56159bfd2
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_test_gwas_snp_tools_b29b507fadc42302'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_b29b507fadc42302', '__yb_builtins_b29b507fadc42302']})
