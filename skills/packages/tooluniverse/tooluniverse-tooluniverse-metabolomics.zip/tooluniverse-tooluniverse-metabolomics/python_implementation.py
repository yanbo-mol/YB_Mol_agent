"""Public interface to the native implementation."""
# Native core SHA256: fb7e01b42bc146f6f56f51b86a47cb614eb50539c684024ebb5e347a652a1cee
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_python_implementation_18fe475b01d5fb5e' if __name__ == "__main__" else '_ybcore_python_implementation_18fe475b01d5fb5e'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_18fe475b01d5fb5e', '__yb_builtins_18fe475b01d5fb5e']})
