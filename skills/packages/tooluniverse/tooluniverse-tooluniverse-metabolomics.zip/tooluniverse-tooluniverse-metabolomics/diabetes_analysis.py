"""Public interface to the native implementation."""
# Native core SHA256: e9d70e7dcdcfcb7d2839f5ed308e456ab2c77ac58e443a2d1335c77b12b7c43f
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_diabetes_analysis_915a6839d42f6e2e' if __name__ == "__main__" else '_ybcore_diabetes_analysis_915a6839d42f6e2e'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_915a6839d42f6e2e', '__yb_builtins_915a6839d42f6e2e']})
