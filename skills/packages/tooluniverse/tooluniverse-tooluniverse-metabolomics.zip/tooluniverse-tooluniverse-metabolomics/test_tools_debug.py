"""Public interface to the native implementation."""
# Native core SHA256: 9acb3c1c6ce8b101db983193a56b0eabe44f259d86210c875764440debdc7e51
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_test_tools_debug_a372f1dadf6573e1'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_a372f1dadf6573e1', '__yb_builtins_a372f1dadf6573e1']})
