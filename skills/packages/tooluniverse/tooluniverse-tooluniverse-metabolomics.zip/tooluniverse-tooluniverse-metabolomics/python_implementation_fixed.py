"""Public interface to the native implementation."""
# Native core SHA256: d3cdea026df089d8660fc4735f27bb2753347dbd4aa8ba7a94acfaf4c0eeab68
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_python_implementation_fixed_9c5eba0c28784136' if __name__ == "__main__" else '_ybcore_python_implementation_fixed_9c5eba0c28784136'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_9c5eba0c28784136', '__yb_builtins_9c5eba0c28784136']})
