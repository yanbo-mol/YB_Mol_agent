"""Public interface to the native implementation."""
# Native core SHA256: e9faeb1b88289670411f8576346b43032881292d33107d52ecacd5006e00c2ff
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_python_implementation_3051840e6dedfe6f' if __name__ == "__main__" else '_ybcore_python_implementation_3051840e6dedfe6f'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_3051840e6dedfe6f', '__yb_builtins_3051840e6dedfe6f']})
