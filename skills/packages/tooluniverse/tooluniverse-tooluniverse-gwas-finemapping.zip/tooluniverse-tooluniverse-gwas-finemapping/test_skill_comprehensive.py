"""Public interface to the native implementation."""
# Native core SHA256: d101261ece21180a54e13afaba93767f04e6064a870b6756b257d4431a4c8ebd
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_test_skill_comprehensive_b0387bdc6c141840' if __name__ == "__main__" else '_ybcore_test_skill_comprehensive_b0387bdc6c141840'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_b0387bdc6c141840', '__yb_builtins_b0387bdc6c141840']})
