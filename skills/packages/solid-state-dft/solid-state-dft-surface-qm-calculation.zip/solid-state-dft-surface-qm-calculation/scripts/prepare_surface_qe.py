"""Public interface to the native implementation."""
# Native core SHA256: 288c70b8ad6400f3d0824d81fd048c0a430c5d17b04f93fb5da119f9cfb94dfe
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_prepare_surface_qe_d19fa7efedb72834' if __name__ == "__main__" else '_ybcore_prepare_surface_qe_d19fa7efedb72834'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_d19fa7efedb72834', '__yb_builtins_d19fa7efedb72834']})
