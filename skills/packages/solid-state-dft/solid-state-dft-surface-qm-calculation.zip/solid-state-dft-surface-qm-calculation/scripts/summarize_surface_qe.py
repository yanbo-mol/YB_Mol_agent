"""Public interface to the native implementation."""
# Native core SHA256: ce82114d443aa882a7c52f6434d2ec396e4b9eb4a0aaddfe855399c021e936d5
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_summarize_surface_qe_f5f98f6c2aa6e8f8' if __name__ == "__main__" else '_ybcore_summarize_surface_qe_f5f98f6c2aa6e8f8'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_f5f98f6c2aa6e8f8', '__yb_builtins_f5f98f6c2aa6e8f8']})
