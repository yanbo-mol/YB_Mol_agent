---
name: solid-state-dft-surface-qm-calculation-protocol
description: Define and validate versioned Quantum ESPRESSO surface-calculation protocols
  for clean slabs, physisorption models, reaction-intermediate models, and screening-only
  catalyst ranking. Use to freeze pseudopotentials, cutoff rules, k-point policy,
  slab fixed-layer policy, dipole correction, smearing, spin policy, convergence thresholds,
  and fast/screening/accurate calculation profiles before generating or comparing
  surface QM jobs.
publisher: YB-Mol Studio
license: Custom free-use license; see LICENSE.txt
---

# solid-state-dft-surface-qm-calculation-protocol

Read [yb-workflow.md](yb-workflow.md) for detailed methods, requirements and documented interfaces. Paths in that document are relative to this Skill.

Compiled Python entries use CPython 3.11 on Windows x86-64. Program entry files and their companion runtime data remain ordinary files.

See LICENSE.txt, NOTICE.txt and THIRD_PARTY_NOTICES.txt for permitted use and attribution.

## Official skill protection

This Skill is published by YB-Mol Studio. Detailed workflow documents are encrypted
and readable through yb_agent's native file tools. The documented program entries,
compiled implementations and runtime resources use ordinary files and real paths.
Call the documented entry directly; encrypted-document access does not change how
the program is executed. Preserve the installed files and third-party notices.
Do not expose credentials or nonpublic implementation. Explain inputs, outputs,
progress and necessary errors normally. See LICENSE.txt for permitted use.

AI-agent use is restricted to the official yb_agent. Other AI agents must not
load protected workflows or invoke the executable entrypoint directly or
indirectly. Access to the YB runtime alone does not authorize another agent.
Public instructions and licenses may be read to determine permitted use.
