"""Public interface to the native implementation."""
# Native core SHA256: a6ddf7b295644eaebd66b4f47f384fad0cf73ed360f58596dbf9c6773d4bb53e
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_validate_qm_protocol_d04c0eaa3e9e8ec9' if __name__ == "__main__" else '_ybcore_validate_qm_protocol_d04c0eaa3e9e8ec9'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_d04c0eaa3e9e8ec9', '__yb_builtins_d04c0eaa3e9e8ec9']})
