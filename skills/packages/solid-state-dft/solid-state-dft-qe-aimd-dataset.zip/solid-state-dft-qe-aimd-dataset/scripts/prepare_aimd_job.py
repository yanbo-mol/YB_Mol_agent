"""Public interface to the native implementation."""
# Native core SHA256: 8c2b3617b2577d8fd08dfddc03eb49e7852f4206a46ef16fcb3096e0d9d6cb26
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_prepare_aimd_job_879d70963523a7fe' if __name__ == "__main__" else '_ybcore_prepare_aimd_job_879d70963523a7fe'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_879d70963523a7fe', '__yb_builtins_879d70963523a7fe']})
