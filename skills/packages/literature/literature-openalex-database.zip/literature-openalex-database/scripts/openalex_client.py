"""Public interface to the native implementation."""
# Native core SHA256: 69c5d75e45a2249ae15ffdc35d4e2aeaba64bbb4139c65878374f7ced624b5d2
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_openalex_client_7e83ae9f932b5aab' if __name__ == "__main__" else '_ybcore_openalex_client_7e83ae9f932b5aab'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_7e83ae9f932b5aab', '__yb_builtins_7e83ae9f932b5aab']})
