"""Public entrypoint for the compiled environment manager."""
from _env_manager_core import *

if __name__ == "__main__":
    raise SystemExit(main())
