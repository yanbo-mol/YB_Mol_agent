"""Public interface to the native implementation."""
# Native core SHA256: 62b6688a9c6d6a817e6354ce30520bc766b31e04a8d93e7609e054b4e2dadf1a
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_spatial_analyzer_5e41d986690684c1' if __name__ == "__main__" else '_ybcore_spatial_analyzer_5e41d986690684c1'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_5e41d986690684c1', '__yb_builtins_5e41d986690684c1']})
