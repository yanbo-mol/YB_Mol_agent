"""Public interface to the native implementation."""
# Native core SHA256: b448f59f188b307eec6bae9de67dfae9bf9c13d086eb67c8a99f1843ba512631
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_preprocess_spatial_fbabd1d28972966c'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_fbabd1d28972966c', '__yb_builtins_fbabd1d28972966c']})
