"""Public interface to the native implementation."""
# Native core SHA256: de49590dc1f475f02bfaaad908986bb4ce109b08e68d2b2e3f9447850ace2c54
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_workflow_7f6596d98b503d1a'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_7f6596d98b503d1a', '__yb_builtins_7f6596d98b503d1a']})
