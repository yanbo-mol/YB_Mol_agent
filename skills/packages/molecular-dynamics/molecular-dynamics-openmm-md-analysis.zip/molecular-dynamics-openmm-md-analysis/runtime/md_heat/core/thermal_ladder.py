"""Public interface to the native implementation."""
# Native core SHA256: 42a9b6e2e7aa52837de944cd1220d3358d18d723628876b4c010d9ae7150c143
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_thermal_ladder_fbec55ad20b5309d'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_fbec55ad20b5309d', '__yb_builtins_fbec55ad20b5309d']})
