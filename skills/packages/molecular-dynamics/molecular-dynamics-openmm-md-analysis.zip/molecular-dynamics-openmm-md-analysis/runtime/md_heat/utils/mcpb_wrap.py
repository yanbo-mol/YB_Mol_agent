"""Public interface to the native implementation."""
# Native core SHA256: 79eb16620e33de4c20ee96fc3d2c1ea414e88fad1788b0d36119ff6dd39896b9
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_mcpb_wrap_d120c62405b77d23'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_d120c62405b77d23', '__yb_builtins_d120c62405b77d23']})
