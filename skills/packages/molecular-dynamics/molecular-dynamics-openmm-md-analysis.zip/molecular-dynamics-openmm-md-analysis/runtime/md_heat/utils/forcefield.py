"""Public interface to the native implementation."""
# Native core SHA256: 0d01e48b5b0a79ce5f72cbab14a5301a40645aa2626b871bc43483b8fa019366
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_forcefield_02bbfe1991c7442a'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_02bbfe1991c7442a', '__yb_builtins_02bbfe1991c7442a']})
