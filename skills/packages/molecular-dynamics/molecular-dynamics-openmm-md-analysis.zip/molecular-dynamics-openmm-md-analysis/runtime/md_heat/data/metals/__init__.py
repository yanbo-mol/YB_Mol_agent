"""Bundled metal-ion force-field fragments."""

import os

DATA_DIR = os.path.dirname(os.path.abspath(__file__))
