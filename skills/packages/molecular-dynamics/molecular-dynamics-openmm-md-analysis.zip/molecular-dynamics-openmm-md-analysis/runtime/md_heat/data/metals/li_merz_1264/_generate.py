"""Public interface to the native implementation."""
# Native core SHA256: cafddd4afb377f2328cdaa6d928abef18511f517deb99a95b42342e25e49758c
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli__generate_2486530256771c05' if __name__ == "__main__" else '_ybcore__generate_2486530256771c05'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_2486530256771c05', '__yb_builtins_2486530256771c05']})
