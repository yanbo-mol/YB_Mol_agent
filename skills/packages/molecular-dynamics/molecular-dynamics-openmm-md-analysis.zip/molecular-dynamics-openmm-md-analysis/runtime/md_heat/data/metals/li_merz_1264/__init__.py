"""Public interface to the native implementation."""
# Native core SHA256: 9daf1439c048cba4da64b96462da4407e108f4b8e0f4e22dbe8aa67622e03ffd
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore___init___3fdea74f0220b9d8'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_3fdea74f0220b9d8', '__yb_builtins_3fdea74f0220b9d8']})
