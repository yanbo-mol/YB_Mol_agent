"""Bundled data files (force-field fragments, parameter tables)."""
