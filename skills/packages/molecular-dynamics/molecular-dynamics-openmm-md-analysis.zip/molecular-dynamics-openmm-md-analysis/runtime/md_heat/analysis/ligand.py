"""Public interface to the native implementation."""
# Native core SHA256: f4cb2eeb2f96d194c81cc239d2899430f216f1636fc3e7846113ada8ab3b7bb2
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_ligand_96e978136a60e6cb'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_96e978136a60e6cb', '__yb_builtins_96e978136a60e6cb']})
