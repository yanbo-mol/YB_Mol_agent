"""Thermal stability analysis module.

All routines accept either an ``mdtraj.Trajectory`` or a pair of
``(topology_file, trajectory_file)`` paths. ``mdtraj`` is loaded lazily so
the core simulation modules remain importable without it.
"""

from .structural import (
    compute_rmsd,
    compute_rmsf,
    compute_rg,
    compute_sasa,
    load_trajectory,
)
from .contacts import native_contacts_Q
from .tm import estimate_tm, sigmoid_model
from .ligand import ligand_rmsd, ligand_pocket_distance
from .run_analysis import (
    DEFAULT_ANALYSES,
    analyze_md_run,
    load_md_run_manifest,
)

__all__ = [
    "compute_rmsd",
    "compute_rmsf",
    "compute_rg",
    "compute_sasa",
    "load_trajectory",
    "native_contacts_Q",
    "estimate_tm",
    "sigmoid_model",
    "ligand_rmsd",
    "ligand_pocket_distance",
    "DEFAULT_ANALYSES",
    "analyze_md_run",
    "load_md_run_manifest",
]
