"""Public interface to the native implementation."""
# Native core SHA256: 9aa1739312d483b217b14268b001a0afbd97543d3adc7305b09a75c81609a19a
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_contacts_e25b7fa36185a483'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_e25b7fa36185a483', '__yb_builtins_e25b7fa36185a483']})
