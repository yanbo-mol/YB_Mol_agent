"""Public interface to the native implementation."""
# Native core SHA256: 0eda62976b5773ebe6d00c8ff3f216628694096dbec9c71e663a858a9c6440ff
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_tm_d66af99e0227fe76'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_d66af99e0227fe76', '__yb_builtins_d66af99e0227fe76']})
