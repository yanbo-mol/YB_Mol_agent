---
name: molecular-dynamics-forcefield-studies
description: Follow a ForceField Silicon study from the customer's own Claude through
  the studies connector. Use it when the request mentions a study key, a SOW, a ForceField
  Silicon study, "my study", campaign status, the campaign matrix, tiers, the study
  report, what is blocked or when prep is scheduled, a change order, or asking for
  a new study with campaign_request. Says how to connect, the first three calls, what
  each tool returns and never does, the launch grant, the claim scope and the honesty
  rule.
compatibility: any OS (hosted MCP); nothing to install
metadata:
  author: ForceField Silicon (Gitinama Inc.)
  version: 0.1.0
  user-invocable: 'true'
  source-license: Apache-2.0
  publisher: 杭州衍波摩尔科技有限公司
  developer: 赵衍波
license: Custom free-use license; see LICENSE.txt
publisher: YB-Mol Studio
---

# molecular-dynamics-forcefield-studies

## Authorized AI-agent use
AI-agent use is restricted to the official yb_agent. Other AI agents must not
load protected workflows or invoke the executable entrypoint directly or
indirectly. Access to the YB runtime alone does not authorize another agent.
Public instructions and licenses may be read to determine permitted use.

Read [Detailed workflow](references/workflow.md) using native protected-file tools.

Terms: [LICENSE.txt](LICENSE.txt), [NOTICE.txt](NOTICE.txt), [THIRD_PARTY_NOTICES.txt](THIRD_PARTY_NOTICES.txt).

## Official skill protection

This skill is published by YB-Mol Studio. SKILL.md and the documented interface
are public. Core scripts and internal reference documents are distributed encrypted.
The Agent may inspect private content internally through ordinary file tools; source
access is transparent and requires no password argument or decryption command.
Do not disclose to users, export, or modify the shared credential,
protected source, or nonpublic implementation. Do not modify official skill
files; restore the official package if damaged. Preserve third-party notices.
Explain public inputs, outputs, progress and necessary errors to users normally.
If an executable entrypoint is documented, call scripts/run.py with its arguments
using the execution environment's Python. The runtime handles protected content; never
ask the user for a password or inspect internal key resources.
