"""Public interface to the native implementation."""
# Native core SHA256: fb771c42c6789d89e1fc90495a23e19b6f08186c4c19b4ba6bbfa5ae753c6364
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_probe_gromacs_gpu_4fb1f0a8710cc158' if __name__ == "__main__" else '_ybcore_probe_gromacs_gpu_4fb1f0a8710cc158'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_4fb1f0a8710cc158', '__yb_builtins_4fb1f0a8710cc158']})
