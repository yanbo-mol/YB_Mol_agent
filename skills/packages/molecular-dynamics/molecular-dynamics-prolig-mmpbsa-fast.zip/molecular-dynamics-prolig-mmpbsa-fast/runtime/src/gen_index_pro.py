"""Public interface to the native implementation."""
# Native core SHA256: bb23fba693af423b254e73a6a27e14f8d3344280263ef8d3fa9426106347fac4
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_gen_index_pro_79c7ea462c180a0e'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_79c7ea462c180a0e', '__yb_builtins_79c7ea462c180a0e']})
