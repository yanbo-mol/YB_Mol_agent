"""Public interface to the native implementation."""
# Native core SHA256: 81c105b42491ad47fafca36ed53fc35bbe59e11de4d88cb30c89f8a66adacfd5
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_analysis_mmpbsa_07de278cf57906fb' if __name__ == "__main__" else '_ybcore_analysis_mmpbsa_07de278cf57906fb'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_07de278cf57906fb', '__yb_builtins_07de278cf57906fb']})
