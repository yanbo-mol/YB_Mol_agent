"""Public interface to the native implementation."""
# Native core SHA256: 4c0b734e464f28dd1de150d7eb841a689fed38574c060ea44a6d7d765d4a4376
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_mmpbsa_diagnostics_024b1f6694ff725e' if __name__ == "__main__" else '_ybcore_mmpbsa_diagnostics_024b1f6694ff725e'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_024b1f6694ff725e', '__yb_builtins_024b1f6694ff725e']})
