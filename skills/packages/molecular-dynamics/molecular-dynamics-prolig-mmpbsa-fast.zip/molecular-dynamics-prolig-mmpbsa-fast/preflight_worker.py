"""Public interface to the native implementation."""
# Native core SHA256: 401b209ae1f827ed1bf1bda1ce301055f1d065bf6774fda868120a87f28f40bc
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_preflight_worker_9c2d4bc8b212d0e5' if __name__ == "__main__" else '_ybcore_preflight_worker_9c2d4bc8b212d0e5'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_9c2d4bc8b212d0e5', '__yb_builtins_9c2d4bc8b212d0e5']})
