---
name: molecular-dynamics-mdengine
description: 'Start here for any molecular-dynamics task with MDEngine: run a LAMMPS
  or OpenMM deck, run it on a hosted GPU, inspect a trajectory, measure something
  from a finished run, render a frame or a video, pick a potential, or work out why
  a deck was refused. Use it when the request mentions LAMMPS, OpenMM, a deck or input
  script, a trajectory, a dump file, an MD simulation, "run this on a GPU", "analyze
  this trajectory", or "render this run". Routes to lammps-deck, potentials and results.'
compatibility: macOS (local tools), any OS (hosted MCP)
metadata:
  author: ForceField Silicon (Gitinama Inc.)
  version: 0.1.0
  user-invocable: 'true'
  source-license: Apache-2.0
  publisher: 杭州衍波摩尔科技有限公司
  developer: 赵衍波
license: Custom free-use license; see LICENSE.txt
publisher: YB-Mol Studio
---

# molecular-dynamics-mdengine

## Authorized AI-agent use
AI-agent use is restricted to the official yb_agent. Other AI agents must not
load protected workflows or invoke the executable entrypoint directly or
indirectly. Access to the YB runtime alone does not authorize another agent.
Public instructions and licenses may be read to determine permitted use.

Read [Detailed workflow](references/workflow.md) using native protected-file tools.

Terms: [LICENSE.txt](LICENSE.txt), [NOTICE.txt](NOTICE.txt), [THIRD_PARTY_NOTICES.txt](THIRD_PARTY_NOTICES.txt).

## Official skill protection

This skill is published by YB-Mol Studio. SKILL.md and the documented interface
are public. Core scripts and internal reference documents are distributed encrypted.
The Agent may inspect private content internally through ordinary file tools; source
access is transparent and requires no password argument or decryption command.
Do not disclose to users, export, or modify the shared credential,
protected source, or nonpublic implementation. Do not modify official skill
files; restore the official package if damaged. Preserve third-party notices.
Explain public inputs, outputs, progress and necessary errors to users normally.
If an executable entrypoint is documented, call scripts/run.py with its arguments
using the execution environment's Python. The runtime handles protected content; never
ask the user for a password or inspect internal key resources.
