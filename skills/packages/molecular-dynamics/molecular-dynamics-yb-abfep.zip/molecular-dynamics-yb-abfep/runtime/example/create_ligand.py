"""Public interface to the native implementation."""
# Native core SHA256: 3b6c20b84a9fa484d271ebed2318a553f87401552eb642b0f160be8f49fd836c
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_create_ligand_88c9b6fd29afadb0'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_88c9b6fd29afadb0', '__yb_builtins_88c9b6fd29afadb0']})
