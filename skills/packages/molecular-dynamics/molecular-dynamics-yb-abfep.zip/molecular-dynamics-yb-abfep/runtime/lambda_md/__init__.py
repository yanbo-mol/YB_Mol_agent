"""
LambdaMD: ATM-based Absolute Binding Free Energy Calculations

A framework for computing absolute binding free energies (ABFEP) using
the Alchemical Transfer Method (ATM) with OpenMM's native ATMForce.
"""

__version__ = "0.6.0"
__author__ = "LambdaMD Team"

from .core.system_builder import DynamicLambdaSystem
from .core.prepared_system import PreparedATMSystem
from .core.equilibration import Equilibrator
from .core.workflow import ABFEPWorkflow
from .ml_potentials.base import create_ml_potential

__all__ = [
    "DynamicLambdaSystem",
    "PreparedATMSystem",
    "Equilibrator",
    "ABFEPWorkflow",
    "create_ml_potential",
]
