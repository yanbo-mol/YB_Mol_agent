"""Plugin bridges for optional LambdaMD backends."""
