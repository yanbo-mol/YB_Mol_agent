"""Public interface to the native implementation."""
# Native core SHA256: 20ab905815e5196d318e55840ee8ff26f381a89b7ae3c83b735aa45f5c279bf9
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_run_abfep_93ed43d863875f36' if __name__ == "__main__" else '_ybcore_run_abfep_93ed43d863875f36'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_93ed43d863875f36', '__yb_builtins_93ed43d863875f36']})
