"""Public interface to the native implementation."""
# Native core SHA256: 074bc67f8bc780b9a3b53fbdbb073ee7cfa1653a812de5203514efc4b462540c
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_ani_0523e86d187f998b'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_0523e86d187f998b', '__yb_builtins_0523e86d187f998b']})
