"""Public interface to the native implementation."""
# Native core SHA256: 64ea24c8982f09842498437c718d3e5b62980ff0d6b09fcea3881ebb0e237f8a
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_forcefield_a80fd14ac1718c1d'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_a80fd14ac1718c1d', '__yb_builtins_a80fd14ac1718c1d']})
