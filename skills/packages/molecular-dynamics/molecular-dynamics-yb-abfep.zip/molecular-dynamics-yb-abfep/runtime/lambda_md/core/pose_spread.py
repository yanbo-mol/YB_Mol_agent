"""Public interface to the native implementation."""
# Native core SHA256: e72bd94814a1e38f7a53d39c9b8ef69ba50c6a557f5f7e164fd23aa58b872b44
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_pose_spread_7817c3eee6f94461'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_7817c3eee6f94461', '__yb_builtins_7817c3eee6f94461']})
