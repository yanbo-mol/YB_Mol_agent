"""Public interface to the native implementation."""
# Native core SHA256: b2c7ef3d1892612a643616333d5f079d8383de1e95b08aba1d9a250b5b487a0b
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_two_copy_builder_720c14d508a8a298'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_720c14d508a8a298', '__yb_builtins_720c14d508a8a298']})
