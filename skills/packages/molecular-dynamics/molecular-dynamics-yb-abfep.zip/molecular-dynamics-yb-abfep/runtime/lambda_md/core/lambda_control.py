"""Public interface to the native implementation."""
# Native core SHA256: 5654b63a47f5f33b736d960c8e5ba088f1d1f53154e5f2884d7553b4441dba00
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_lambda_control_65db8304ca1ad7f3'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_65db8304ca1ad7f3', '__yb_builtins_65db8304ca1ad7f3']})
