"""Public interface to the native implementation."""
# Native core SHA256: 8a0c502b3bcf36f65b13909fbd76b4846399a4355a2e87d7b21fe7eae44b1672
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_prepared_system_f066abf36154cba0'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_f066abf36154cba0', '__yb_builtins_f066abf36154cba0']})
