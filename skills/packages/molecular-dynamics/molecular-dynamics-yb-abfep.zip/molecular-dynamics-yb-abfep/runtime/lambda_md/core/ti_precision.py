"""Public interface to the native implementation."""
# Native core SHA256: 135ab27a7a7b7a034e593d0b9e228fa8e644e740a812be678ddcfcba2f29851d
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_ti_precision_0d326fd2b2a9714c'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_0d326fd2b2a9714c', '__yb_builtins_0d326fd2b2a9714c']})
