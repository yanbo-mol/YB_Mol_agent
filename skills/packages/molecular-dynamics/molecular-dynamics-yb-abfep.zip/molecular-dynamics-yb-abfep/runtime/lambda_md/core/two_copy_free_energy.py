"""Public interface to the native implementation."""
# Native core SHA256: d961b4e0db0a3997f9d049af340d75c18085da2875a02cd6ec6c552017a62604
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_two_copy_free_energy_3c2bffc52d73c1ec'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_3c2bffc52d73c1ec', '__yb_builtins_3c2bffc52d73c1ec']})
