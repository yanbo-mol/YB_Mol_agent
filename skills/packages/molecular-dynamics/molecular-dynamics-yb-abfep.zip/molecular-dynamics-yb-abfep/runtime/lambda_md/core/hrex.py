"""Public interface to the native implementation."""
# Native core SHA256: 7f3d29d82d44002ae8afaca5893dea9cc000793af6dd3dbb35a1d083dc7c1181
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_hrex_d3c78289645ca1d6'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_d3c78289645ca1d6', '__yb_builtins_d3c78289645ca1d6']})
