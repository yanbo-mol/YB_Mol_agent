"""Public interface to the native implementation."""
# Native core SHA256: 9117599d3bf781d99e08407fc4f409faa6dfa501869f8a6815d36d070cb10415
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_split_box_factory_87fa2cc49f1216fb'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_87fa2cc49f1216fb', '__yb_builtins_87fa2cc49f1216fb']})
