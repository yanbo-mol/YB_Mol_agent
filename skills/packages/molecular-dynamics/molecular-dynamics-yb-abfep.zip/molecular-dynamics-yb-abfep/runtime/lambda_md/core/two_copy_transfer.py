"""Public interface to the native implementation."""
# Native core SHA256: d5f4e0a947e30f62cd91d5225697cf5099724bf9e944d878356e0040a776194f
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_two_copy_transfer_09d473b755be44ac'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_09d473b755be44ac', '__yb_builtins_09d473b755be44ac']})
