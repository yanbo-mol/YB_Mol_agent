"""Public interface to the native implementation."""
# Native core SHA256: eb4d7192b6ff59e247e9edbf3c3223f1cbce2dca57e9e5fc0f3572fd2d445baf
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_workflow_4c4690aacb8722b0'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_4c4690aacb8722b0', '__yb_builtins_4c4690aacb8722b0']})
