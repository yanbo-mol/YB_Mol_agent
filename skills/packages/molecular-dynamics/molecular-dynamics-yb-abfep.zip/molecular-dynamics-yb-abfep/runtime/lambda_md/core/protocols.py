"""Public interface to the native implementation."""
# Native core SHA256: ffd7b800b011e4e4c0f4634e302a213332dc6d220c11b8a24a439b71d8b88cbc
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_protocols_b39040961061f243'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_b39040961061f243', '__yb_builtins_b39040961061f243']})
