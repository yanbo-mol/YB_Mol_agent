"""Public interface to the native implementation."""
# Native core SHA256: 395062693d84f83108b327cc55508e49a07216591a83a05aa89de2b8220cd3e3
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_check_environment_b51fa418c085fd6e' if __name__ == "__main__" else '_ybcore_check_environment_b51fa418c085fd6e'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_b51fa418c085fd6e', '__yb_builtins_b51fa418c085fd6e']})
