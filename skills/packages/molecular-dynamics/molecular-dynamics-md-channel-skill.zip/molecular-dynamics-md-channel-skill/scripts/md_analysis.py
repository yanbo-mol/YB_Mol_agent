"""Public interface to the native implementation."""
# Native core SHA256: 51bb27c32af9ff723f637e226c4b827d7572936f484f0b716446ff5ce3d0ebd7
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_md_analysis_4e9775801c267baf' if __name__ == "__main__" else '_ybcore_md_analysis_4e9775801c267baf'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_4e9775801c267baf', '__yb_builtins_4e9775801c267baf']})
