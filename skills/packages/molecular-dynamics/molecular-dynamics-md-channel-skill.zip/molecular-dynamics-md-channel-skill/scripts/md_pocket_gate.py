"""Public interface to the native implementation."""
# Native core SHA256: c4bdc16992a2550d3e8b246b4ff2a3ef0cef12e2c2ce5797adbfaf1b2b7195e7
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_md_pocket_gate_5e9f0f99c623508a' if __name__ == "__main__" else '_ybcore_md_pocket_gate_5e9f0f99c623508a'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_5e9f0f99c623508a', '__yb_builtins_5e9f0f99c623508a']})
