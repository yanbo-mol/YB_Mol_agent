"""Public interface to the native implementation."""
# Native core SHA256: 16c397932c76ed42edca804e34c12b3e9889f79f611e956fe8fb65fa13776bc5
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_md_coupling_pathway_243cc5a1fc61a8bd' if __name__ == "__main__" else '_ybcore_md_coupling_pathway_243cc5a1fc61a8bd'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_243cc5a1fc61a8bd', '__yb_builtins_243cc5a1fc61a8bd']})
