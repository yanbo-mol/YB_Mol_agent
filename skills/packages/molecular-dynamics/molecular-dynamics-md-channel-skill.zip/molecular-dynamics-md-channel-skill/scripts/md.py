"""Public interface to the native implementation."""
# Native core SHA256: f5d081fce655a1b8b602953285a5d2dcd9b385b0e87da33dbe37cf2c30d3e4c0
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_md_9d5bd3136d33156a' if __name__ == "__main__" else '_ybcore_md_9d5bd3136d33156a'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_9d5bd3136d33156a', '__yb_builtins_9d5bd3136d33156a']})
