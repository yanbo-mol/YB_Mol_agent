"""Public interface to the native implementation."""
# Native core SHA256: e581e2d9ca31141ab4b3c0ebb17f4be4ce3675a79306b719b4e9364d210e79a7
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_md_channel_analysis_1861d793553fd6b7' if __name__ == "__main__" else '_ybcore_md_channel_analysis_1861d793553fd6b7'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_1861d793553fd6b7', '__yb_builtins_1861d793553fd6b7']})
