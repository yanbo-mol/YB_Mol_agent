"""Public interface to the native implementation."""
# Native core SHA256: 17391c2e90bc3c20e8688e0842993aa78077b48b4856efafd03907a6d32cae1f
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_check_environment_2edc2f2ba1df4b2b' if __name__ == "__main__" else '_ybcore_check_environment_2edc2f2ba1df4b2b'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_2edc2f2ba1df4b2b', '__yb_builtins_2edc2f2ba1df4b2b']})
