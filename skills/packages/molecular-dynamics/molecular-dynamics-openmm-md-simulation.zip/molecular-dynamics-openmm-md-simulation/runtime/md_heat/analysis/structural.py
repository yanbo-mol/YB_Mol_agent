"""Public interface to the native implementation."""
# Native core SHA256: d7c9cd0f057c930437d79b1c903db9e10c255e18ed8522e3a17f78acc9cda476
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_structural_6f51c1d7a8dca5ff'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_6f51c1d7a8dca5ff', '__yb_builtins_6f51c1d7a8dca5ff']})
