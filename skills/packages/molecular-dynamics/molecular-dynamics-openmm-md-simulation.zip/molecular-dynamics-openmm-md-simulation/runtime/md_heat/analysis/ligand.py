"""Public interface to the native implementation."""
# Native core SHA256: 965279ff93f55d3fe51a34cbdbc907023eff7947aa03ac143dd771109e4572a0
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_ligand_dfa2c9321c9dd696'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_dfa2c9321c9dd696', '__yb_builtins_dfa2c9321c9dd696']})
