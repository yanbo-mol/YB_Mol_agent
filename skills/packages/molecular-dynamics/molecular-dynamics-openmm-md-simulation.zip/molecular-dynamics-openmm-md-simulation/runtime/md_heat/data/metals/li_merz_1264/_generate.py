"""Public interface to the native implementation."""
# Native core SHA256: 82398d02673ef7eff0aadb3f9b12f3a44fb4bb998b4c8259816b2eedbbdb96c3
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli__generate_f4f88f7a141a6c75' if __name__ == "__main__" else '_ybcore__generate_f4f88f7a141a6c75'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_f4f88f7a141a6c75', '__yb_builtins_f4f88f7a141a6c75']})
