"""Public interface to the native implementation."""
# Native core SHA256: 4d1e04614f4cc252d9d944e59926648ef5ccbe8386b2a28eb2e2604842458c96
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_thermal_screen_9f010fb6527ec530'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_9f010fb6527ec530', '__yb_builtins_9f010fb6527ec530']})
