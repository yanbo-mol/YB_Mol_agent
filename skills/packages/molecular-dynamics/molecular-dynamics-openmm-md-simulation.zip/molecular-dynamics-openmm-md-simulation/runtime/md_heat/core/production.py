"""Public interface to the native implementation."""
# Native core SHA256: 8b6e75653b47c080a933e1a2e61c9e1d799583c4353b1e18c1814a546c11b313
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_production_3d4b3116fd11765a'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_3d4b3116fd11765a', '__yb_builtins_3d4b3116fd11765a']})
