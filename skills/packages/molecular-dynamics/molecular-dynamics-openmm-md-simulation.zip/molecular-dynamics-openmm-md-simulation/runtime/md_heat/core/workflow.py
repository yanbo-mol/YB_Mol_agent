"""Public interface to the native implementation."""
# Native core SHA256: 39410f22256b5493ac53e28f064949afc1c3d26ca8e9a06b8de3a880699b2c53
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_workflow_c9d2943d233a9f1f'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_c9d2943d233a9f1f', '__yb_builtins_c9d2943d233a9f1f']})
