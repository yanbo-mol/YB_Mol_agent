"""Public interface to the native implementation."""
# Native core SHA256: 953d4a7e6974bcddd5ce9d6b08f7b5308645b27e83636895e97716ca971edbee
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_prepared_system_c6af3731963f378f'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_c6af3731963f378f', '__yb_builtins_c6af3731963f378f']})
