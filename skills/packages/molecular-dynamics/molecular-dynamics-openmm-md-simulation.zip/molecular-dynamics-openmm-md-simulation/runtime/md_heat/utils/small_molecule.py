"""Public interface to the native implementation."""
# Native core SHA256: cf19250a4cdb09ed2e9934a603b1ede2f844a52cc7a8a527e19cf30b7572ec7f
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_small_molecule_edc0d3abbbec4dd5'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_edc0d3abbbec4dd5', '__yb_builtins_edc0d3abbbec4dd5']})
