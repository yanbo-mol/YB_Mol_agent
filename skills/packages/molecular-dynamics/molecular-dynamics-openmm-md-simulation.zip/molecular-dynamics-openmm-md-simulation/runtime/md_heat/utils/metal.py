"""Public interface to the native implementation."""
# Native core SHA256: ee2e66242a9646e7ee53039993866c1d561f77a782d9c302f436d53807a33430
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_metal_511e6369eab277a0'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_511e6369eab277a0', '__yb_builtins_511e6369eab277a0']})
