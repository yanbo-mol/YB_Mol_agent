#!/bin/bash
export YB_ORIGINAL_SCRIPT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/$(basename -- "${BASH_SOURCE[0]}")"
exec "${YB_ORIGINAL_SCRIPT}.bin" "$@"
