---
name: molecular-dynamics-openfe-septop
description: 使用 OpenFE SepTop 对缺乏可靠公共原子映射的两个配体执行 pairwise RBFE，完成 complex/solvent
  热力学循环、Boresch 约束、CUDA quickrun 与恢复；不用于 hybrid 网络规划、ABFE 或普通 MD。
publisher: YB-Mol Studio
license: Custom free-use license; see LICENSE.txt
---

# molecular-dynamics-openfe-septop

Read [yb-workflow.md](yb-workflow.md) for detailed methods, requirements and documented interfaces. Paths in that document are relative to this Skill.

The compiled mixed-language programs target Linux x86-64, with CPython 3.11 where Python is present. R and Bash requirements remain as documented. Program entry files and their companion runtime data remain ordinary files.

See LICENSE.txt, NOTICE.txt and THIRD_PARTY_NOTICES.txt for permitted use and attribution.

## Official skill protection

This Skill is published by YB-Mol Studio. Detailed workflow documents are encrypted
and readable through yb_agent's native file tools. The documented program entries,
compiled implementations and runtime resources use ordinary files and real paths.
Call the documented entry directly; encrypted-document access does not change how
the program is executed. Preserve the installed files and third-party notices.
Do not expose credentials or nonpublic implementation. Explain inputs, outputs,
progress and necessary errors normally. See LICENSE.txt for permitted use.

AI-agent use is restricted to the official yb_agent. Other AI agents must not
load protected workflows or invoke the executable entrypoint directly or
indirectly. Access to the YB runtime alone does not authorize another agent.
Public instructions and licenses may be read to determine permitted use.
