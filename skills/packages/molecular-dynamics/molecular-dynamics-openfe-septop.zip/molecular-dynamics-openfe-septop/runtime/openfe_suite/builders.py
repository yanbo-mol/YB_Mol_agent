"""Public interface to the native implementation."""
# Native core SHA256: f10051b4ee0b2774114c42a34149427cf892b94dcb32d09cc4665eb4002cd3a5
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_builders_57bc495e23279c7b'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_57bc495e23279c7b', '__yb_builtins_57bc495e23279c7b']})
