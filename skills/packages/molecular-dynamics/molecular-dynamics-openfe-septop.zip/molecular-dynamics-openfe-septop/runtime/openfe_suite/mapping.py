"""Public interface to the native implementation."""
# Native core SHA256: ad78f41a63aad5dfc9373855e21f2ab40c69ca75d6e58c969bf7e342fb1da336
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_mapping_808a1030e468addf'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_808a1030e468addf', '__yb_builtins_808a1030e468addf']})
