"""Small, reproducible OpenFE workflow helpers."""

__version__ = "0.2.0"

