"""Public interface to the native implementation."""
# Native core SHA256: 62ea49b9eb55bb67c58d19d65f352a12c46e0dab0b29526b90ac3ee400d09980
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_test_skill_0cecbf9d4f64abd7' if __name__ == "__main__" else '_ybcore_test_skill_0cecbf9d4f64abd7'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_0cecbf9d4f64abd7', '__yb_builtins_0cecbf9d4f64abd7']})
