"""Public interface to the native implementation."""
# Native core SHA256: 8b19ac8b4696f48d48736a8a2cd891fd90e56989925c69a50eeedcbbca0e6ec6
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_run_360e5540ecbbda2c'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_360e5540ecbbda2c', '__yb_builtins_360e5540ecbbda2c']})
