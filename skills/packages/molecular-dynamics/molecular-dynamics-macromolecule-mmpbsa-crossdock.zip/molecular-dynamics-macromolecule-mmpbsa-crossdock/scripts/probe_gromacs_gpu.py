"""Public interface to the native implementation."""
# Native core SHA256: 83993c26c3ebe999b24f2f41cfa4fb184e3c558731795fa886ac3e2dcde9d4a6
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_probe_gromacs_gpu_e0617b739ce7191b' if __name__ == "__main__" else '_ybcore_probe_gromacs_gpu_e0617b739ce7191b'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_e0617b739ce7191b', '__yb_builtins_e0617b739ce7191b']})
