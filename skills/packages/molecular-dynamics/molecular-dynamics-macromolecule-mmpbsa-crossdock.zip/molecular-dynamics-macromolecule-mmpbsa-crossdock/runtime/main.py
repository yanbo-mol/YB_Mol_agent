"""Public interface to the native implementation."""
# Native core SHA256: 5a0fe6a332463d0a62365455db67ef7c657dba4d6512b1610d97575a93963594
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_main_1ede4fbe94a88e08' if __name__ == "__main__" else '_ybcore_main_1ede4fbe94a88e08'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_1ede4fbe94a88e08', '__yb_builtins_1ede4fbe94a88e08']})
