"""Public interface to the native implementation."""
# Native core SHA256: 9d35d6b71d6a23e1a6ee88344578df76959d238c1b7a6e961e1e4c7e6f1c252c
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_batch_run_ppi_92f13e784d0fcd10' if __name__ == "__main__" else '_ybcore_batch_run_ppi_92f13e784d0fcd10'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_92f13e784d0fcd10', '__yb_builtins_92f13e784d0fcd10']})
