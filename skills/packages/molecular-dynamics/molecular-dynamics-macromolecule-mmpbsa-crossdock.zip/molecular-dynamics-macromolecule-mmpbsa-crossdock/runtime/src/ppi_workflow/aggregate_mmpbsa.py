"""Public interface to the native implementation."""
# Native core SHA256: 5df83f69776491b3570d2f12e985a1d100187ab5c54ddf53d84ac0d6df23e621
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_aggregate_mmpbsa_a5c9df96bfe143ce' if __name__ == "__main__" else '_ybcore_aggregate_mmpbsa_a5c9df96bfe143ce'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_a5c9df96bfe143ce', '__yb_builtins_a5c9df96bfe143ce']})
