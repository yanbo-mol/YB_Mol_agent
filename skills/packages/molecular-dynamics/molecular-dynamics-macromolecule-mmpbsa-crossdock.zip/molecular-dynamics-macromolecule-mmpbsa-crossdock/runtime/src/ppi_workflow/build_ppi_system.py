"""Public interface to the native implementation."""
# Native core SHA256: 14ee26b40337dd4fc49f3bf93b57e5532a8e8e38df638c629c6ca81e3e30818d
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_build_ppi_system_ed5d51d18c33a266' if __name__ == "__main__" else '_ybcore_build_ppi_system_ed5d51d18c33a266'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_ed5d51d18c33a266', '__yb_builtins_ed5d51d18c33a266']})
