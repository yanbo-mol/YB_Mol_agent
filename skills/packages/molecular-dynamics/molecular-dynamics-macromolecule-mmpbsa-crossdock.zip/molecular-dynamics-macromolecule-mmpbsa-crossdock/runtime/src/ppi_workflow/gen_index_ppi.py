"""Public interface to the native implementation."""
# Native core SHA256: 6edd1a3c11d02797c7dd22b56732a21378589ab0ee5af0a023cba2521f08545f
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_gen_index_ppi_cb02308c695fea1c' if __name__ == "__main__" else '_ybcore_gen_index_ppi_cb02308c695fea1c'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_cb02308c695fea1c', '__yb_builtins_cb02308c695fea1c']})
