"""Public interface to the native implementation."""
# Native core SHA256: 0c1d940914a3af3084b33304461a9ac34e895188505ddee1457480c8cf979242
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_run_metad_mmpbsa_workflow_5910f8578b2c9670' if __name__ == "__main__" else '_ybcore_run_metad_mmpbsa_workflow_5910f8578b2c9670'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_5910f8578b2c9670', '__yb_builtins_5910f8578b2c9670']})
