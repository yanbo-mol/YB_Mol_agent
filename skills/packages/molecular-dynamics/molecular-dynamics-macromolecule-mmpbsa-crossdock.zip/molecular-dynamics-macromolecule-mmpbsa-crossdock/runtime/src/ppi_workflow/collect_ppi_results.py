"""Public interface to the native implementation."""
# Native core SHA256: e11f9d87759ea2fc4d31a0aa1a8230b0b95120adce21707293afc8de89ce8d97
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_collect_ppi_results_2db1b28f65d196af' if __name__ == "__main__" else '_ybcore_collect_ppi_results_2db1b28f65d196af'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_2db1b28f65d196af', '__yb_builtins_2db1b28f65d196af']})
