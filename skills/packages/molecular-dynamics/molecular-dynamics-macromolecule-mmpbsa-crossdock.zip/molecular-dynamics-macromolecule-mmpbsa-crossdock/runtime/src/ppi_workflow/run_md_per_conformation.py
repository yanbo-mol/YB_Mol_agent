"""Public interface to the native implementation."""
# Native core SHA256: e1759ac32dab6cfc1411cc4f7d8c42d90694602f121375930a7f147ed2b38ad9
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_run_md_per_conformation_d7e8752c79dddb43' if __name__ == "__main__" else '_ybcore_run_md_per_conformation_d7e8752c79dddb43'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_d7e8752c79dddb43', '__yb_builtins_d7e8752c79dddb43']})
