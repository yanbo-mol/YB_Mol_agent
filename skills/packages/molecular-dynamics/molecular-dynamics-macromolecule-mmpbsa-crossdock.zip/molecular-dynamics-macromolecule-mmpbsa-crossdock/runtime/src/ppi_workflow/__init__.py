"""
蛋白-蛋白/核酸MMPBSA工作流包

这是一个用于蛋白-蛋白/核酸相互作用MMPBSA计算的完整工作流工具包。
"""

__version__ = "1.0.0"
__author__ = "ProR PPI Team"

# 可以在这里添加公共API导出
# from .build_ppi_system import build_system
# from .batch_run_ppi import process_single_complex

__all__ = [
    # 将来可以在这里列出公开接口
]
