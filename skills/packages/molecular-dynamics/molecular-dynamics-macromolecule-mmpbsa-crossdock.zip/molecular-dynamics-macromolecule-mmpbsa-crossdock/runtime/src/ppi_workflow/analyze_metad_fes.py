"""Public interface to the native implementation."""
# Native core SHA256: a4f6765e5d18fa6d35696c00d6dd0e1de5259748b1e4f1aa0cdc2d490ffe440b
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_analyze_metad_fes_e1fa0d84b33cb29d' if __name__ == "__main__" else '_ybcore_analyze_metad_fes_e1fa0d84b33cb29d'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_e1fa0d84b33cb29d', '__yb_builtins_e1fa0d84b33cb29d']})
