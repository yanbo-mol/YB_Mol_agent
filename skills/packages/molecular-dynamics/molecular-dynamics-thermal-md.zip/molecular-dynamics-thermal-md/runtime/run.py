"""Public interface to the native implementation."""
# Native core SHA256: 2971c96b6d5de7d7883be639324b38676980af72ccbc1664ab9279d693b3bfb5
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_run_8ea9b90708d07030' if __name__ == "__main__" else '_ybcore_run_8ea9b90708d07030'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_8ea9b90708d07030', '__yb_builtins_8ea9b90708d07030']})
