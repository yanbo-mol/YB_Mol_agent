"""Public interface to the native implementation."""
# Native core SHA256: 1ee8c7ef0da44bf19842ff01d9cdb6f93d06de66895b59304206168977169603
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_mcpb_wrap_e88de6a5f97ba1e0'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_e88de6a5f97ba1e0', '__yb_builtins_e88de6a5f97ba1e0']})
