"""Public interface to the native implementation."""
# Native core SHA256: 0e40d8fe3c6b8fe75981bd2f3ff9289ed9ae9f429c08f3afe55f57a29baa8675
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_prepared_system_f80fed80103d0054'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_f80fed80103d0054', '__yb_builtins_f80fed80103d0054']})
