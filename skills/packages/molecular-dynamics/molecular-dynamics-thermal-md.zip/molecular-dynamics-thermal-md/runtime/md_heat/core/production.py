"""Public interface to the native implementation."""
# Native core SHA256: 6751aaf00e41a97e99efd85c18525a243160dd92302fe1e7320b20f2a71d7363
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_production_b6b3e3d93b67ad6c'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_b6b3e3d93b67ad6c', '__yb_builtins_b6b3e3d93b67ad6c']})
