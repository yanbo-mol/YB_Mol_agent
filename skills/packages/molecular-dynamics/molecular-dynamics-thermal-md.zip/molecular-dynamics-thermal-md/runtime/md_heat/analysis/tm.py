"""Public interface to the native implementation."""
# Native core SHA256: c3d9ec646c98c6c4949d4893a4071e963a25e3dd1d3ccdd7a64cd355ae6c36c6
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_tm_7574095c6a8a2eb8'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_7574095c6a8a2eb8', '__yb_builtins_7574095c6a8a2eb8']})
