"""Public interface to the native implementation."""
# Native core SHA256: 084b14653369beb26d72f2ddc6dba7511ac00375fc9d441ac52a6f5541570e23
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_contacts_bdaee2eb73da2636'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_bdaee2eb73da2636', '__yb_builtins_bdaee2eb73da2636']})
