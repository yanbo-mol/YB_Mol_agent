"""Public interface to the native implementation."""
# Native core SHA256: 2d051118029eaa3c9c7c152db0056e515fa2bebef3e0f811bbca6d8256d38428
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_cli_2582361fd932f335' if __name__ == "__main__" else '_ybcore_cli_2582361fd932f335'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_2582361fd932f335', '__yb_builtins_2582361fd932f335']})
