"""Public interface to the native implementation."""
# Native core SHA256: ee8f913e8e90240e15ac64232798643a64cb4ef1afb90f7fcb2e287e9882f96e
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_analysis_d1a0b08f3f60196a'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_d1a0b08f3f60196a', '__yb_builtins_d1a0b08f3f60196a']})
