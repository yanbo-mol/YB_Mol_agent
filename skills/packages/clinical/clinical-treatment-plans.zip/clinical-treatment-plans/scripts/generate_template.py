"""Public interface to the native implementation."""
# Native core SHA256: 205abe8de0c0328d3e77b5b8bbf3e4b2dc51ab941bf17e7a9860de30abdb54cc
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_generate_template_ad49b2967058075e' if __name__ == "__main__" else '_ybcore_generate_template_ad49b2967058075e'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_ad49b2967058075e', '__yb_builtins_ad49b2967058075e']})
