"""Public interface to the native implementation."""
# Native core SHA256: 511292f083f2bcdb74f89fc1bf2b2ad585e0c31ace39ca6b45f72cf9aee2d51a
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_timeline_generator_004d9a66020db811' if __name__ == "__main__" else '_ybcore_timeline_generator_004d9a66020db811'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_004d9a66020db811', '__yb_builtins_004d9a66020db811']})
