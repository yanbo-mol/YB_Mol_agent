"""Public interface to the native implementation."""
# Native core SHA256: 2999acf54b4a4bbeef6db0aed675e9bf6954bc71b8e20a086efa668361fa9eb1
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_basic_protocol_template_d0016e820986c968'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_d0016e820986c968', '__yb_builtins_d0016e820986c968']})


metadata = {'protocolName': 'Basic Protocol Template', 'author': 'Your Name <email@example.com>', 'description': 'A basic protocol template for Opentrons', 'apiLevel': '2.19'}

requirements = {'robotType': 'Flex', 'apiLevel': '2.19'}

def run(protocol):
    return __yb_core.run(protocol)
