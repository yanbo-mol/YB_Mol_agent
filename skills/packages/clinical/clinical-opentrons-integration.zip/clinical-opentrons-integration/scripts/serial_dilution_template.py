"""Public interface to the native implementation."""
# Native core SHA256: ad6f045ffc28e06831278707e4039bd5b8e7a906670ba9abe9b64af94c764b77
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_serial_dilution_template_0e8e7d53093057ec'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_0e8e7d53093057ec', '__yb_builtins_0e8e7d53093057ec']})


metadata = {'protocolName': 'Serial Dilution Template', 'author': 'Opentrons', 'description': 'Serial dilution protocol for creating concentration gradients', 'apiLevel': '2.19'}

requirements = {'robotType': 'Flex', 'apiLevel': '2.19'}

def run(protocol):
    return __yb_core.run(protocol)
