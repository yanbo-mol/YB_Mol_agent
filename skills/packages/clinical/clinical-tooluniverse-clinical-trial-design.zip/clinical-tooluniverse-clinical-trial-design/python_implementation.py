"""Public interface to the native implementation."""
# Native core SHA256: 76cc75be9135947f65c709761bc1b59b1f94bde576e4f07df6b0d7ae210e9493
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_python_implementation_ea95c58c547b958f' if __name__ == "__main__" else '_ybcore_python_implementation_ea95c58c547b958f'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_ea95c58c547b958f', '__yb_builtins_ea95c58c547b958f']})
