"""Public interface to the native implementation."""
# Native core SHA256: c6f27132f90ea9e8666f152dae04ae5bfcc61dba69ab48feab4050e268d1298b
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_opentrons_generator_9c355645e46c1e92' if __name__ == "__main__" else '_ybcore_opentrons_generator_9c355645e46c1e92'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_9c355645e46c1e92', '__yb_builtins_9c355645e46c1e92']})
