"""Public interface to the native implementation."""
# Native core SHA256: f785dd0f482b6b952fe9e625e3bab002f7e7673b402dd0819016940796c378de
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_clinpgx_a8a6fb55a063622e' if __name__ == "__main__" else '_ybcore_clinpgx_a8a6fb55a063622e'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_a8a6fb55a063622e', '__yb_builtins_a8a6fb55a063622e']})
