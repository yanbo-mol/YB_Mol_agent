"""Public interface to the native implementation."""
# Native core SHA256: 38487244fec28ba0edb9491d15441f625dfd7d52e3185da39ce56ab8a07c1052
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_test_image_analysis_e60342e59e5c4d9e' if __name__ == "__main__" else '_ybcore_test_image_analysis_e60342e59e5c4d9e'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_e60342e59e5c4d9e', '__yb_builtins_e60342e59e5c4d9e']})
