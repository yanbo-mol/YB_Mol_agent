"""Public interface to the native implementation."""
# Native core SHA256: 9723db5a326e20a4d4b124d90b25be9e68f4b02988249a3b6cb4135c995802f8
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_usage_a279d6c28a28b8b0' if __name__ == "__main__" else '_ybcore_usage_a279d6c28a28b8b0'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_a279d6c28a28b8b0', '__yb_builtins_a279d6c28a28b8b0']})
