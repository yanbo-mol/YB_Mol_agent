"""Public interface to the native implementation."""
# Native core SHA256: dea2907048a05b24eab03958a7d447650af82af17d2f43de17847bec91695457
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_medprompt_utils_6b9275a93fb452ba' if __name__ == "__main__" else '_ybcore_medprompt_utils_6b9275a93fb452ba'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_6b9275a93fb452ba', '__yb_builtins_6b9275a93fb452ba']})
