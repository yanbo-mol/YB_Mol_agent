"""Public interface to the native implementation."""
# Native core SHA256: ca332e4b79bddbdd1d5088a782145d64c5120f8e000d09bb251c2fa21a37dff7
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_entity_extractor_fc9f18f8a7669185' if __name__ == "__main__" else '_ybcore_entity_extractor_fc9f18f8a7669185'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_fc9f18f8a7669185', '__yb_builtins_fc9f18f8a7669185']})
