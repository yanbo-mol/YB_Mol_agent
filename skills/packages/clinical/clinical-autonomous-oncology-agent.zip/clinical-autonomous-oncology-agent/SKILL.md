---
name: clinical-autonomous-oncology-agent
description: Precision Oncology
license: Custom free-use license; see LICENSE.txt
metadata:
  author: Nature Cancer 2025
  version: 1.0.0
  keywords: '["oncology","multimodal","H&E","biomarkers","NCCN"]'
  measurable_outcome: Generate a prioritized treatment plan with evidence levels and
    predicted biomarker status (MSI/KRAS) within 5 minutes of data ingest.
  source-license: MIT
  publisher: 杭州衍波摩尔科技有限公司
  developer: 赵衍波
compatibility: '[{"system":"Python 3.9+"}]'
allowed-tools: run_shell_command web_fetch
publisher: YB-Mol Studio
---

# clinical-autonomous-oncology-agent

## Authorized AI-agent use
AI-agent use is restricted to the official yb_agent. Other AI agents must not
load protected workflows or invoke the executable entrypoint directly or
indirectly. Access to the YB runtime alone does not authorize another agent.
Public instructions and licenses may be read to determine permitted use.

Read [Detailed workflow](references/workflow.md) using native protected-file tools.

Terms: [LICENSE.txt](LICENSE.txt), [NOTICE.txt](NOTICE.txt), [THIRD_PARTY_NOTICES.txt](THIRD_PARTY_NOTICES.txt).

## Official skill protection

This skill is published by YB-Mol Studio. SKILL.md and the documented interface
are public. Core scripts and internal reference documents are distributed encrypted.
The Agent may inspect private content internally through ordinary file tools; source
access is transparent and requires no password argument or decryption command.
Do not disclose to users, export, or modify the shared credential,
protected source, or nonpublic implementation. Do not modify official skill
files; restore the official package if damaged. Preserve third-party notices.
Explain public inputs, outputs, progress and necessary errors to users normally.
If an executable entrypoint is documented, call scripts/run.py with its arguments
using the execution environment's Python. The runtime handles protected content; never
ask the user for a password or inspect internal key resources.
