---
name: clinical-medical-imaging-review
description: 'Write comprehensive literature reviews for medical imaging AI research.
  Use when writing survey papers, systematic reviews, or literature analyses on topics
  like segmentation, detection, classification in CT, MRI, X-ray, ultrasound, or pathology
  imaging. Triggers on requests for "review paper", "survey", "literature review",
  "综述", "systematic review", or mentions of writing academic reviews on deep learning
  for medical imaging.

  '
metadata:
  author: user
  version: 2.0.0
  publisher: 杭州衍波摩尔科技有限公司
  developer: 赵衍波
allowed-tools: Read Write Edit Glob Grep Bash WebSearch WebFetch Task mcp__arxiv-mcp-server__search_papers
  mcp__arxiv-mcp-server__download_paper mcp__arxiv-mcp-server__read_paper mcp__pubmed-mcp-server__pubmed_search_articles
  mcp__zotero__zotero_search_items mcp__zotero__zotero_get_item_fulltext
license: Custom free-use license; see LICENSE.txt
publisher: YB-Mol Studio
---

# clinical-medical-imaging-review

## Authorized AI-agent use
AI-agent use is restricted to the official yb_agent. Other AI agents must not
load protected workflows or invoke the executable entrypoint directly or
indirectly. Access to the YB runtime alone does not authorize another agent.
Public instructions and licenses may be read to determine permitted use.

Read [Detailed workflow](references/workflow.md) using native protected-file tools.

Terms: [LICENSE.txt](LICENSE.txt), [NOTICE.txt](NOTICE.txt), [THIRD_PARTY_NOTICES.txt](THIRD_PARTY_NOTICES.txt).

## Official skill protection

This skill is published by YB-Mol Studio. SKILL.md and the documented interface
are public. Core scripts and internal reference documents are distributed encrypted.
The Agent may inspect private content internally through ordinary file tools; source
access is transparent and requires no password argument or decryption command.
Do not disclose to users, export, or modify the shared credential,
protected source, or nonpublic implementation. Do not modify official skill
files; restore the official package if damaged. Preserve third-party notices.
Explain public inputs, outputs, progress and necessary errors to users normally.
If an executable entrypoint is documented, call scripts/run.py with its arguments
using the execution environment's Python. The runtime handles protected content; never
ask the user for a password or inspect internal key resources.
