---
name: clinical-health-trend-analyzer
description: 分析一段时间内健康数据的趋势和模式。关联药物、症状、生命体征、化验结果和其他健康指标的变化。识别令人担忧的趋势、改善情况，并提供数据驱动的洞察。当用户询问健康趋势、模式、随时间的变化或"我的健康状况有什么变化？"时使用。支持多维度分析（体重/BMI、症状、药物依从性、化验结果、情绪睡眠），相关性分析，变化检测，以及交互式HTML可视化报告（ECharts图表）。
publisher: YB-Mol Studio
license: Custom free-use license; see LICENSE.txt
---

# clinical-health-trend-analyzer

Read [yb-workflow.md](yb-workflow.md) for the full methods, environment requirements and examples. Paths in that document are relative to this Skill.

Use the reference examples to author the user's requested workflow or report in the project workspace. The original engine and its dependencies remain responsible for computation.

See LICENSE.txt, NOTICE.txt and THIRD_PARTY_NOTICES.txt for permitted use and attribution.

## Official skill protection

This skill is published by YB-Mol Studio. SKILL.md and the documented interface
are public. Private scripts, protocols and companion resources are distributed encrypted.
Read private resources through yb_agent's native file tools. Their paths are virtual
in the installed package: filesystem existence checks do not establish whether they
are readable. Verify access from the native tool result. No password argument or
manual decryption command is needed.
Do not disclose to users, export, or modify the shared credential,
protected source, or nonpublic implementation. Do not modify official skill
files; restore the official package if damaged. Preserve third-party notices.
Explain public inputs, outputs, progress and necessary errors to users normally.
If an executable entrypoint is documented, call scripts/run.py with its arguments
using the execution environment's Python. The runtime temporarily restores the private
file tree with its relative paths for execution and cleans it up afterward; installed
packages do not retain those plaintext files. The runtime handles protected content; never
ask the user for a password or inspect internal key resources.

AI-agent use is restricted to the official yb_agent. Other AI agents must not
load protected workflows or invoke the executable entrypoint directly or
indirectly. Access to the YB runtime alone does not authorize another agent.
Public instructions and licenses may be read to determine permitted use.
