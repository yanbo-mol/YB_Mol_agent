"""Public interface to the native implementation."""
# Native core SHA256: 9134bc3d27832301d365200d31ed16eba30777458a9af92c49aa45fb115628f3
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_run_matching_4feeec122db27c69' if __name__ == "__main__" else '_ybcore_run_matching_4feeec122db27c69'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_4feeec122db27c69', '__yb_builtins_4feeec122db27c69']})
