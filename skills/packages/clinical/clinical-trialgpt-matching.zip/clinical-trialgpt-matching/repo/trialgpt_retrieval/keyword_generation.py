"""Public interface to the native implementation."""
# Native core SHA256: 0bd73f7149e17eb4d64ba4377d5b36a81c9acd5a6da64ae5d51e683c87b9f1dc
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_keyword_generation_75d5e545292b581b' if __name__ == "__main__" else '_ybcore_keyword_generation_75d5e545292b581b'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_75d5e545292b581b', '__yb_builtins_75d5e545292b581b']})
