#!/usr/bin/env node
require('../vendor/bytenode');
const core=require('./crisis_detector.jsc');
module.exports=core;
if(require.main===module)core.__yb_runCLI();
