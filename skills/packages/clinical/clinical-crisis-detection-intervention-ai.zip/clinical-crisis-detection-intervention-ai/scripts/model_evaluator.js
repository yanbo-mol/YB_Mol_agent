#!/usr/bin/env node
require('../vendor/bytenode');
const core=require('./model_evaluator.jsc');
module.exports=core;
if(require.main===module)core.__yb_runCLI();
