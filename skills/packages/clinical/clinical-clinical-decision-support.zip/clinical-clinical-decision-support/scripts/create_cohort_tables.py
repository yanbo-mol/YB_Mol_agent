"""Public interface to the native implementation."""
# Native core SHA256: 774ca10e38ebe2b10a83bd4184395c4f90a14ee693b96c35dc1a32f883f36caa
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_create_cohort_tables_70646f78fe9a9481' if __name__ == "__main__" else '_ybcore_create_cohort_tables_70646f78fe9a9481'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_70646f78fe9a9481', '__yb_builtins_70646f78fe9a9481']})
