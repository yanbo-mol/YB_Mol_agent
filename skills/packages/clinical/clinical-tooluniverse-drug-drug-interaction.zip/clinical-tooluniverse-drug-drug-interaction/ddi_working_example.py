"""Public interface to the native implementation."""
# Native core SHA256: 77d677ee398e2646a81854bc0a1b4ffb27d5efd5fccb2ded3b722e0cf3e277e8
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_ddi_working_example_25c209a3d2f3db4a' if __name__ == "__main__" else '_ybcore_ddi_working_example_25c209a3d2f3db4a'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_25c209a3d2f3db4a', '__yb_builtins_25c209a3d2f3db4a']})
