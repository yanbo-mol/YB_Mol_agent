"""Public interface to the native implementation."""
# Native core SHA256: a42dadac8f8092a8d3b4546540e1dde2469e43698f24817a8a9d164d94d42ccc
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_arrhythmia_detector_ccede4ac0c639a0b' if __name__ == "__main__" else '_ybcore_arrhythmia_detector_ccede4ac0c639a0b'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_ccede4ac0c639a0b', '__yb_builtins_ccede4ac0c639a0b']})
