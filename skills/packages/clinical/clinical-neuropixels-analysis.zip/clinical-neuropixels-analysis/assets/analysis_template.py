"""Public interface to the native implementation."""
# Native core SHA256: bc664433647bb881b8d1f8725a2fbf94ff2d05e8cc64c7ef92700e7ded6d8c76
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_analysis_template_8154753bfbd8c805' if __name__ == "__main__" else '_ybcore_analysis_template_8154753bfbd8c805'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_8154753bfbd8c805', '__yb_builtins_8154753bfbd8c805']})
