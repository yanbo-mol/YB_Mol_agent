"""Public interface to the native implementation."""
# Native core SHA256: 025498fa64bc9fb5bf6c618ec484368aab807444057c011965b19bb5ea9ee044
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_compute_metrics_accb2987d48d1904' if __name__ == "__main__" else '_ybcore_compute_metrics_accb2987d48d1904'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_accb2987d48d1904', '__yb_builtins_accb2987d48d1904']})
