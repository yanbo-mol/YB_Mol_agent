"""Public interface to the native implementation."""
# Native core SHA256: 7766d4bff9be9dedd56305dc06c09ce1377fafb75d9d67fe80df04123ad0fcc3
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_export_to_phy_7fa8ee7424576f18' if __name__ == "__main__" else '_ybcore_export_to_phy_7fa8ee7424576f18'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_7fa8ee7424576f18', '__yb_builtins_7fa8ee7424576f18']})
