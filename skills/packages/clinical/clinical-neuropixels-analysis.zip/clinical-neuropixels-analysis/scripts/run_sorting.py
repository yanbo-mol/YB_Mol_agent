"""Public interface to the native implementation."""
# Native core SHA256: b1f1bd98e7be22e48691e4a1a903d811d0fcb15e37600bb3253e22ec76048148
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_run_sorting_f1bfd3041bdcac30' if __name__ == "__main__" else '_ybcore_run_sorting_f1bfd3041bdcac30'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_f1bfd3041bdcac30', '__yb_builtins_f1bfd3041bdcac30']})
