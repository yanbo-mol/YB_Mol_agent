"""Public interface to the native implementation."""
# Native core SHA256: 248b92df051ede2026733256225b125ee87ed95b272da9d43230bae3b647c872
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_explore_recording_0815774e312f949b' if __name__ == "__main__" else '_ybcore_explore_recording_0815774e312f949b'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_0815774e312f949b', '__yb_builtins_0815774e312f949b']})
