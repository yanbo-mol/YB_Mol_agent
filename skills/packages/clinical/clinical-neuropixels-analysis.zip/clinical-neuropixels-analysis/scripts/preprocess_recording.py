"""Public interface to the native implementation."""
# Native core SHA256: e4e8846f6a9869ad5b9dd1d6f51283bd15dac2090d8090cb0f6c78a79a89caf4
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_preprocess_recording_51fdafa37abfd7bc' if __name__ == "__main__" else '_ybcore_preprocess_recording_51fdafa37abfd7bc'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_51fdafa37abfd7bc', '__yb_builtins_51fdafa37abfd7bc']})
