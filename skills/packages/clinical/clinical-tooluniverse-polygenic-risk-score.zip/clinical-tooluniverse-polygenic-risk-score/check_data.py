"""Public interface to the native implementation."""
# Native core SHA256: 55d55262e1edcbebee0465766db819a49e6958441979fdca9b8316ba9a897c96
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcore_check_data_6686e6b7f34a1fc3'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_6686e6b7f34a1fc3', '__yb_builtins_6686e6b7f34a1fc3']})
