"""Public interface to the native implementation."""
# Native core SHA256: 22e533a0d87e924d03a894b04c497f37782e8d7debfbc5c2a2d1e1090a64c5ca
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_test_prs_tools_a0a46756087f1187' if __name__ == "__main__" else '_ybcore_test_prs_tools_a0a46756087f1187'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_a0a46756087f1187', '__yb_builtins_a0a46756087f1187']})
