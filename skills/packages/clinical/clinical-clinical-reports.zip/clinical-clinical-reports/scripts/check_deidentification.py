"""Public interface to the native implementation."""
# Native core SHA256: 47bcc7dbd400d8e42d6de7ea139beff4d800bb7423dee3af67d80512304ef8a9
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_check_deidentification_325939fb06cdc652' if __name__ == "__main__" else '_ybcore_check_deidentification_325939fb06cdc652'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_325939fb06cdc652', '__yb_builtins_325939fb06cdc652']})
