"""Public interface to the native implementation."""
# Native core SHA256: 664e3d296eb7843bb6648da04f0ddd98e2e16ab38d4c1a47fbad9bfc09d0dfa8
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_validate_case_report_0bb4d814e4ed1d98' if __name__ == "__main__" else '_ybcore_validate_case_report_0bb4d814e4ed1d98'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_0bb4d814e4ed1d98', '__yb_builtins_0bb4d814e4ed1d98']})
