"""Public interface to the native implementation."""
# Native core SHA256: 5467ef0c65a28b98b5a46c243c0daf6478f111b817fbf5d5c6f93923350851dc
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_format_adverse_events_a4c4b2ad640b72b6' if __name__ == "__main__" else '_ybcore_format_adverse_events_a4c4b2ad640b72b6'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_a4c4b2ad640b72b6', '__yb_builtins_a4c4b2ad640b72b6']})
