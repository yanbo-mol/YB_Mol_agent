"""Public interface to the native implementation."""
# Native core SHA256: a2b7ec20b55606ba47842f7667d07ed9ebedaf8415f7b5dadbaedb998bb2d054
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_compliance_checker_ccfe9678a97fcbc3' if __name__ == "__main__" else '_ybcore_compliance_checker_ccfe9678a97fcbc3'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_ccfe9678a97fcbc3', '__yb_builtins_ccfe9678a97fcbc3']})
