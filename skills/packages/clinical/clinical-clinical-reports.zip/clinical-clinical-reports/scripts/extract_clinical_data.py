"""Public interface to the native implementation."""
# Native core SHA256: b920905321a705717076b1f6f26b2b3d9b65efeeb4e002813e5411458227f5e0
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_extract_clinical_data_3bde5e381c4b7ce6' if __name__ == "__main__" else '_ybcore_extract_clinical_data_3bde5e381c4b7ce6'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_3bde5e381c4b7ce6', '__yb_builtins_3bde5e381c4b7ce6']})
