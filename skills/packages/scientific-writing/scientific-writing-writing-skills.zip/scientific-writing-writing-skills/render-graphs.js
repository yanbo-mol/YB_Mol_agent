#!/usr/bin/env node
require("./vendor/bytenode");
require('./render-graphs.jsc');
