"""Public interface to the native implementation."""
# Native core SHA256: 3f3ecad7325d75e0146157a57971f493822ffc180ba1e9523fe02d65cbfa6966
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_compliance_checker_075da47687ecc932' if __name__ == "__main__" else '_ybcore_compliance_checker_075da47687ecc932'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_075da47687ecc932', '__yb_builtins_075da47687ecc932']})
