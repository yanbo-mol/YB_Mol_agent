"""Public interface to the native implementation."""
# Native core SHA256: 56813e824c3d5c333c1e44b1b1aa30e68cc1fb86e2add116f950d6c1415e491a
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_crystal_mapper_477ca56429574225' if __name__ == "__main__" else '_ybcore_crystal_mapper_477ca56429574225'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_477ca56429574225', '__yb_builtins_477ca56429574225']})
