"""Public interface to the native implementation."""
# Native core SHA256: 7baab8cda9e70920c4efa0c98c0f9e1a8c27f768a5fd77b4a2994193eb47d5bc
import importlib as __yb_importlib
import sys as __yb_sys
from pathlib import Path as __yb_Path
__yb_sys.path.insert(0,str(__yb_Path(__file__).resolve().parent))
__yb_target='_ybcli_concept_mapper_0d580f1cf1ab8d8d' if __name__ == "__main__" else '_ybcore_concept_mapper_0d580f1cf1ab8d8d'
__yb_core=__yb_importlib.import_module("."+__yb_target,package=__package__) if __package__ else __yb_importlib.import_module(__yb_target)
globals().update({k:v for k,v in vars(__yb_core).items() if k not in ['__name__', '__file__', '__package__', '__loader__', '__spec__', '__cached__', '__builtins__', '__yb_file_os_0d580f1cf1ab8d8d', '__yb_builtins_0d580f1cf1ab8d8d']})
